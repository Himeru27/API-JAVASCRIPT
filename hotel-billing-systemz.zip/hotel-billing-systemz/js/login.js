const baseApiUrl = "http://localhost/hotel-billing-systemz/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

document.addEventListener("DOMContentLoaded", () => {
  //if already logged in, go straight to the dashboard
  if (sessionStorage.getItem("loggedInUser")) {
    window.location.href = "index.html";
    return;
  }

  document.getElementById("btn-login").addEventListener("click", () => {
    login();
  });

  document.getElementById("password").addEventListener("keyup", (e) => {
    if (e.key === "Enter") {
      login();
    }
  });
});

const login = async () => {
  const jsonData = {
    username: document.getElementById("username").value,
    password: document.getElementById("password").value,
  };

  const formData = new FormData();
  formData.append("operation", "login");
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({
    url: `${baseApiUrl}/user.php`,
    method: "POST",
    data: formData,
  });

  const errorDiv = document.getElementById("login-error");

  if (response.data && response.data !== 0) {
    sessionStorage.setItem("loggedInUser", JSON.stringify(response.data));
    window.location.href = "index.html";
  } else {
    errorDiv.innerText = "Invalid username or password.";
    errorDiv.classList.remove("d-none");
  }
};
