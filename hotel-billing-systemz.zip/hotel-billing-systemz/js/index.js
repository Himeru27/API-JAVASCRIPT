import { viewGuestModal, updateGuestModal, deleteGuestModal } from "../modules/guest.js";
import { assignRoomModal, bookingDetailsModal, cancelBookingModal } from "../modules/booking.js";
import { payStatementModal } from "../modules/payment.js";
import { resetPasswordModal, deactivateUserModal, reactivateUser } from "../modules/user.js";

const baseApiUrl = "api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

let guestTypes = [];
let roomTypes = [];
let floors = [];
let rooms = [];
let guests = [];
let roomStatuses = [];
let roles = [];
let rolePermissions = [];

let editingRoomTypeId = null;
let editingFloorId = null;
let editingRoomId = null;
let editingUserId = null;
let editingGuestTypeId = null;
let editingRoleId = null;
let editingRoomStatusId = null;
let editingPaymentTypeId = null;
let editingPaymentStatusId = null;
let editingChargeCategoryId = null;
let editingChargeCategoryTaxable = 1;
let editingServiceTypeId = null;
let chargeCategories = [];

document.addEventListener("DOMContentLoaded", async () => {
  const loggedInUser = JSON.parse(sessionStorage.getItem("loggedInUser") || "null");
  if (!loggedInUser) {
    window.location.href = "login.html";
    return;
  }

  document.getElementById("welcome-text").innerText = `Welcome, ${loggedInUser.first_name} (${loggedInUser.role_type})`;

  const FEATURE_TABS = {
    guests: "guests-tab-item",
    rooms: "rooms-tab-item",
    bookings: "bookings-tab-item",
    billing: "billing-tab-item",
    housekeeping: "housekeeping-tab-item",
    users: "users-tab-item",
    settings: "settings-tab-item",
  };

  const isAdministrator = loggedInUser.role_type === "Administrator";
  let allowedFeatures = Object.keys(FEATURE_TABS);
  if (!isAdministrator) {
    allowedFeatures = (loggedInUser.permissions || "").split(",").filter(Boolean);
    try {
      const response = await axios.get(`${baseApiUrl}/role.php`, { params: { operation: "getRolePermissions" } });
      if (Array.isArray(response.data)) {
        allowedFeatures = response.data
          .filter((permission) => permission.role_id == loggedInUser.role_id)
          .map((permission) => permission.feature_key);
        loggedInUser.permissions = allowedFeatures.join(",");
        sessionStorage.setItem("loggedInUser", JSON.stringify(loggedInUser));
      }
    } catch (error) {
      // Keep the session permissions if the role-permission request is unavailable.
    }
  }

  Object.entries(FEATURE_TABS).forEach(([feature, tabItemId]) => {
    if (!allowedFeatures.includes(feature)) {
      const el = document.getElementById(tabItemId);
      if (el) el.remove();
    }
  });

  Object.keys(FEATURE_TABS).forEach((feature) => {
    if (!allowedFeatures.includes(feature)) {
      const pane = document.getElementById(`tab-${feature}`);
      if (pane) {
        pane.classList.remove("show", "active");
        pane.classList.add("d-none");
      }
    }
  });

  if (!allowedFeatures.includes("guests")) {
    const firstButton = document.querySelector("#main-tabs .nav-link");
    if (firstButton) {
      firstButton.classList.add("active");
      document.querySelector(firstButton.dataset.bsTarget).classList.add("show", "active");
    }
  }

  document.getElementById("btn-logout").addEventListener("click", () => {
    sessionStorage.removeItem("loggedInUser");
    window.location.href = "login.html";
  });


  displayGuestTypes();
  displayGuests();
  displayRoomTypes();
  displayFloors();
  displayRooms();
  displayBookingGuestOptions();
  displayBookings();
  displayStatements();
  displayRoomStatusOptions();
  displayHousekeepingRoomOptions();
  displayHousekeeping();
  if (isAdministrator) {
    displayRoles();
    displayUsers();
    displayPaymentTypes();
    displayPaymentStatuses();
    displayChargeCategories();
    displayServiceTypes();
  }

  document.getElementById("btn-guest-submit").addEventListener("click", () => insertGuest());
  document.getElementById("btn-room-type-submit").addEventListener("click", () => submitRoomType());
  document.getElementById("btn-floor-submit").addEventListener("click", () => submitFloor());
  document.getElementById("btn-room-submit").addEventListener("click", () => submitRoom());
  document.getElementById("btn-booking-submit").addEventListener("click", () => insertBooking());
  document.getElementById("btn-hk-submit").addEventListener("click", () => insertHousekeeping());

  const userSubmitBtn = document.getElementById("btn-user-submit");
  if (userSubmitBtn) {
    userSubmitBtn.addEventListener("click", () => submitUser());
  }

  const guestTypeSubmitBtn = document.getElementById("btn-guest-type-submit");
  if (guestTypeSubmitBtn) guestTypeSubmitBtn.addEventListener("click", () => submitGuestType());

  const roleSubmitBtn = document.getElementById("btn-role-submit");
  if (roleSubmitBtn) roleSubmitBtn.addEventListener("click", () => submitRole());

  const roomStatusSubmitBtn = document.getElementById("btn-room-status-submit");
  if (roomStatusSubmitBtn) roomStatusSubmitBtn.addEventListener("click", () => submitRoomStatus());

  const paymentTypeSubmitBtn = document.getElementById("btn-payment-type-submit");
  if (paymentTypeSubmitBtn) paymentTypeSubmitBtn.addEventListener("click", () => submitPaymentType());

  const paymentStatusSubmitBtn = document.getElementById("btn-payment-status-submit");
  if (paymentStatusSubmitBtn) paymentStatusSubmitBtn.addEventListener("click", () => submitPaymentStatus());

  const chargeCategorySubmitBtn = document.getElementById("btn-charge-category-submit");
  if (chargeCategorySubmitBtn) chargeCategorySubmitBtn.addEventListener("click", () => submitChargeCategory());

  const serviceTypeSubmitBtn = document.getElementById("btn-service-type-submit");
  if (serviceTypeSubmitBtn) serviceTypeSubmitBtn.addEventListener("click", () => submitServiceType());
});



const displayGuestTypes = async () => {
  const response = await axios.get(`${baseApiUrl}/guest_type.php`, { params: { operation: "getGuestTypes" } });
  if (response.status == 200) {
    guestTypes = response.data;
    const select = document.getElementById("guest-type");
    select.innerHTML = "";
    guestTypes.forEach((type) => {
      let option = document.createElement("option");
      option.innerText = type.guest_type;
      option.value = type.guest_type_id;
      select.appendChild(option);
    });
    displayGuestTypesTable(guestTypes);
  } else {
    alert("Error!");
  }
};


const displayGuestTypesTable = (list) => {
  const tableDiv = document.getElementById("guest-types-table-div");
  if (!tableDiv) return;
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Type</th><th>Discount %</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((gt) => {
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${gt.guest_type}</td>
        <td>${gt.discount_percentage}</td>
        <td>
          <button type="button" class="btn btn-success btn-sm btn-edit">Edit</button>
          <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-edit").addEventListener("click", () => editGuestType(gt));
    row.querySelector(".btn-delete").addEventListener("click", () => deleteGuestType(gt.guest_type_id));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const editGuestType = (gt) => {
  editingGuestTypeId = gt.guest_type_id;
  document.getElementById("guest-type-name").value = gt.guest_type;
  document.getElementById("guest-type-discount").value = gt.discount_percentage;
  document.getElementById("guest-type-privilege").value = gt.privilege ?? "";
};

const submitGuestType = async () => {
  const jsonData = {
    guestType: document.getElementById("guest-type-name").value,
    discountPercentage: document.getElementById("guest-type-discount").value,
    privilege: document.getElementById("guest-type-privilege").value,
  };

  const operation = editingGuestTypeId ? "updateGuestType" : "insertGuestType";
  if (editingGuestTypeId) jsonData.guestTypeId = editingGuestTypeId;

  const formData = new FormData();
  formData.append("operation", operation);
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/guest_type.php`, method: "POST", data: formData });

  if (response.data == 1) {
    editingGuestTypeId = null;
    document.getElementById("guest-type-name").value = "";
    document.getElementById("guest-type-discount").value = "";
    document.getElementById("guest-type-privilege").value = "";
    displayGuestTypes();
  } else {
    alert("ERROR");
  }
};

const deleteGuestType = async (guestTypeId) => {
  if (!confirm("Delete this guest type?")) return;
  const params = { operation: "deleteGuestType", json: JSON.stringify({ guestTypeId }) };
  const response = await axios.get(`${baseApiUrl}/guest_type.php`, { params });
  if (response.data == 1) {
    displayGuestTypes();
  } else if (response.data == -1) {
    alert("This guest type cannot be deleted because it is already used by existing guests.");
  } else {
    alert("ERROR");
  }
};

const displayGuests = async () => {
  const response = await axios.get(`${baseApiUrl}/guest.php`, { params: { operation: "getAllGuests" } });
  if (response.status == 200) {
    guests = response.data;
    displayGuestsTable(guests);
    displayBookingGuestOptions();
  } else {
    alert("Error!");
  }
};

const displayGuestsTable = (guestList) => {
  const tableDiv = document.getElementById("guests-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");

  const thead = document.createElement("thead");
  thead.innerHTML = `
      <tr>
        <th>NAME</th>
        <th>CONTACT NO.</th>
        <th>GUEST TYPE</th>
        <th>ACTION</th>
      </tr>
    `;
  table.appendChild(thead);

  const tbody = document.createElement("tbody");
  guestList.forEach((guest) => {
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${guest.first_name} ${guest.last_name}</td>
        <td>${guest.contact_number ?? ""}</td>
        <td>${guest.guest_type}</td>
        <td>
          <button type="button" class="btn btn-primary btn-sm btn-view">View</button>
          <button type="button" class="btn btn-success btn-sm btn-update">Update</button>
          <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-view").addEventListener("click", () => viewGuestModal(guest.guest_id));
    row.querySelector(".btn-update").addEventListener("click", () => updateGuestModal(guest.guest_id, guestTypes, displayGuests));
    row.querySelector(".btn-delete").addEventListener("click", () => deleteGuestModal(guest.guest_id, displayGuests));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const insertGuest = async () => {
  const jsonData = {
    firstName: document.getElementById("guest-first-name").value,
    lastName: document.getElementById("guest-last-name").value,
    contactNumber: document.getElementById("guest-contact-number").value,
    email: document.getElementById("guest-email").value,
    address: document.getElementById("guest-address").value,
    guestTypeId: document.getElementById("guest-type").value,
  };

  const formData = new FormData();
  formData.append("operation", "insertGuest");
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/guest.php`, method: "POST", data: formData });

  if (response.data == 1) {
    displayGuests();
    document.getElementById("guest-first-name").value = "";
    document.getElementById("guest-last-name").value = "";
    document.getElementById("guest-contact-number").value = "";
    document.getElementById("guest-email").value = "";
    document.getElementById("guest-address").value = "";
    alert("Guest Successfully Registered!");
  } else {
    alert("ERROR");
  }
};


const displayRoomTypes = async () => {
  const response = await axios.get(`${baseApiUrl}/room_type.php`, { params: { operation: "getAllRoomTypes" } });
  if (response.status == 200) {
    roomTypes = response.data;
    displayRoomTypesTable(roomTypes);
    loadActiveRoomTypesForDropdown();
  } else {
    alert("Error!");
  }
};

const loadActiveRoomTypesForDropdown = async () => {
  const response = await axios.get(`${baseApiUrl}/room_type.php`, { params: { operation: "getActiveRoomTypes" } });
  const select = document.getElementById("room-room-type");
  select.innerHTML = "";
  response.data.forEach((rt) => {
    let option = document.createElement("option");
    option.innerText = rt.room_type_name;
    option.value = rt.room_type_id;
    select.appendChild(option);
  });
};

const displayRoomTypesTable = (list) => {
  const tableDiv = document.getElementById("room-types-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Name</th><th>Rate</th><th>Status</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((rt) => {
    const isActive = rt.is_active == 1;
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${rt.room_type_name}</td>
        <td>${rt.rate_per_night}</td>
        <td>${isActive ? "Active" : "Disabled"}</td>
        <td>
          <button type="button" class="btn btn-success btn-sm btn-edit">Edit</button>
          ${isActive
            ? `<button type="button" class="btn btn-danger btn-sm btn-retire">Disable</button>`
            : `<button type="button" class="btn btn-secondary btn-sm btn-reactivate">Reactivate</button>`}
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-edit").addEventListener("click", () => editRoomType(rt));
    const retireBtn = row.querySelector(".btn-retire");
    if (retireBtn) retireBtn.addEventListener("click", () => retireRoomType(rt.room_type_id));
    const reactivateBtn = row.querySelector(".btn-reactivate");
    if (reactivateBtn) reactivateBtn.addEventListener("click", () => reactivateRoomType(rt.room_type_id));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const editRoomType = (rt) => {
  editingRoomTypeId = rt.room_type_id;
  document.getElementById("room-type-name").value = rt.room_type_name;
  document.getElementById("room-type-description").value = rt.room_type_description ?? "";
  document.getElementById("room-type-capacity").value = rt.capacity;
  document.getElementById("room-type-rate").value = rt.rate_per_night;
};

const submitRoomType = async () => {
  const jsonData = {
    roomTypeName: document.getElementById("room-type-name").value,
    roomTypeDescription: document.getElementById("room-type-description").value,
    capacity: document.getElementById("room-type-capacity").value,
    ratePerNight: document.getElementById("room-type-rate").value,
  };

  const operation = editingRoomTypeId ? "updateRoomType" : "insertRoomType";
  if (editingRoomTypeId) jsonData.roomTypeId = editingRoomTypeId;

  const formData = new FormData();
  formData.append("operation", operation);
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/room_type.php`, method: "POST", data: formData });

  if (response.data == 1) {
    editingRoomTypeId = null;
    document.getElementById("room-type-name").value = "";
    document.getElementById("room-type-description").value = "";
    document.getElementById("room-type-capacity").value = "";
    document.getElementById("room-type-rate").value = "";
    displayRoomTypes();
  } else {
    alert("ERROR");
  }
};


const retireRoomType = async (roomTypeId) => {
  if (!confirm("Disable this room type? It will no longer be selectable for new rooms, but existing rooms and bookings keep referencing it.")) return;
  const params = { operation: "retireRoomType", json: JSON.stringify({ roomTypeId }) };
  const response = await axios.get(`${baseApiUrl}/room_type.php`, { params });
  if (response.data == 1) {
    displayRoomTypes();
  } else {
    alert("ERROR");
  }
};

const reactivateRoomType = async (roomTypeId) => {
  const params = { operation: "reactivateRoomType", json: JSON.stringify({ roomTypeId }) };
  const response = await axios.get(`${baseApiUrl}/room_type.php`, { params });
  if (response.data == 1) {
    displayRoomTypes();
  } else {
    alert("ERROR");
  }
};


const displayFloors = async () => {
  const response = await axios.get(`${baseApiUrl}/floor.php`, { params: { operation: "getAllFloors" } });
  if (response.status == 200) {
    floors = response.data;
    displayFloorsTable(floors);
    populateFloorSelect();
  } else {
    alert("Error!");
  }
};

const populateFloorSelect = () => {
  const select = document.getElementById("room-floor");
  select.innerHTML = "";
  floors.forEach((f) => {
    let option = document.createElement("option");
    option.innerText = f.floor_name;
    option.value = f.floor_id;
    select.appendChild(option);
  });
};

const displayFloorsTable = (list) => {
  const tableDiv = document.getElementById("floors-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>#</th><th>Name</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((f) => {
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${f.floor_number}</td>
        <td>${f.floor_name}</td>
        <td>
          <button type="button" class="btn btn-success btn-sm btn-edit">Edit</button>
          <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-edit").addEventListener("click", () => editFloor(f));
    row.querySelector(".btn-delete").addEventListener("click", () => deleteFloor(f.floor_id));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const editFloor = (f) => {
  editingFloorId = f.floor_id;
  document.getElementById("floor-number").value = f.floor_number;
  document.getElementById("floor-name").value = f.floor_name;
};

const submitFloor = async () => {
  const jsonData = {
    floorNumber: document.getElementById("floor-number").value,
    floorName: document.getElementById("floor-name").value,
  };

  const operation = editingFloorId ? "updateFloor" : "insertFloor";
  if (editingFloorId) jsonData.floorId = editingFloorId;

  const formData = new FormData();
  formData.append("operation", operation);
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/floor.php`, method: "POST", data: formData });

  if (response.data == 1) {
    editingFloorId = null;
    document.getElementById("floor-number").value = "";
    document.getElementById("floor-name").value = "";
    displayFloors();
  } else {
    alert("ERROR");
  }
};

const deleteFloor = async (floorId) => {
  if (!confirm("Delete this floor?")) return;
  const params = { operation: "deleteFloor", json: JSON.stringify({ floorId }) };
  const response = await axios.get(`${baseApiUrl}/floor.php`, { params });
  if (response.data == 1) {
    displayFloors();
  } else if (response.data == -1) {
    alert("This floor cannot be deleted because it still has rooms assigned to it.");
  } else {
    alert("ERROR");
  }
};


const displayRooms = async () => {
  const response = await axios.get(`${baseApiUrl}/rooms.php`, { params: { operation: "getAllRooms" } });
  if (response.status == 200) {
    rooms = response.data;
    displayRoomsTable(rooms);
    displayHousekeepingRoomOptions();
  } else {
    alert("Error!");
  }
};

const displayRoomsTable = (list) => {
  const tableDiv = document.getElementById("rooms-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Room #</th><th>Type</th><th>Floor</th><th>Status</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((r) => {
    const isRetired = r.room_status === "Retired";
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${r.room_number}</td>
        <td>${r.room_type_name}</td>
        <td>${r.floor_name}</td>
        <td>${r.room_status === "Retired" ? "Disabled" : r.room_status}</td>
        <td>
          <button type="button" class="btn btn-success btn-sm btn-edit">Edit</button>
          ${isRetired
            ? `<button type="button" class="btn btn-secondary btn-sm btn-reactivate">Reactivate</button>`
            : `<button type="button" class="btn btn-danger btn-sm btn-retire">Disable</button>`}
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-edit").addEventListener("click", () => editRoom(r));
    const retireBtn = row.querySelector(".btn-retire");
    if (retireBtn) retireBtn.addEventListener("click", () => retireRoom(r.room_id));
    const reactivateBtn = row.querySelector(".btn-reactivate");
    if (reactivateBtn) reactivateBtn.addEventListener("click", () => reactivateRoomEntry(r.room_id));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const editRoom = (r) => {
  editingRoomId = r.room_id;
  document.getElementById("room-room-type").value = r.room_type_id;
  document.getElementById("room-floor").value = r.floor_id;
  document.getElementById("room-number").value = r.room_number;
};

const submitRoom = async () => {
  const availableStatus = roomStatuses.find((s) => s.room_status === "Available");
  const jsonData = {
    roomTypeId: document.getElementById("room-room-type").value,
    floorId: document.getElementById("room-floor").value,
    roomNumber: document.getElementById("room-number").value,
    roomStatusId: availableStatus ? availableStatus.room_status_id : 1,
  };

  const operation = editingRoomId ? "updateRoom" : "insertRoom";
  if (editingRoomId) jsonData.roomId = editingRoomId;

  const formData = new FormData();
  formData.append("operation", operation);
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/rooms.php`, method: "POST", data: formData });

  if (response.data == 1) {
    editingRoomId = null;
    document.getElementById("room-number").value = "";
    displayRooms();
  } else {
    alert("ERROR");
  }
};


const retireRoom = async (roomId) => {
  if (!confirm("Disable this room? It will be taken out of circulation for new bookings, but its history is kept.")) return;
  const params = { operation: "retireRoom", json: JSON.stringify({ roomId }) };
  const response = await axios.get(`${baseApiUrl}/rooms.php`, { params });
  if (response.data == 1) {
    displayRooms();
  } else {
    alert("ERROR");
  }
};

const reactivateRoomEntry = async (roomId) => {
  const params = { operation: "reactivateRoom", json: JSON.stringify({ roomId }) };
  const response = await axios.get(`${baseApiUrl}/rooms.php`, { params });
  if (response.data == 1) {
    displayRooms();
  } else {
    alert("ERROR");
  }
};


const displayBookingGuestOptions = () => {
  const select = document.getElementById("booking-guest");
  if (!select) return;
  select.innerHTML = "";
  guests.forEach((g) => {
    let option = document.createElement("option");
    option.innerText = `${g.first_name} ${g.last_name}`;
    option.value = g.guest_id;
    select.appendChild(option);
  });
};

const displayBookings = async () => {
  const response = await axios.get(`${baseApiUrl}/booking.php`, { params: { operation: "getAllBookings" } });
  if (response.status == 200) {
    displayBookingsTable(response.data);
  } else {
    alert("Error!");
  }
};

const displayBookingsTable = (bookings) => {
  const tableDiv = document.getElementById("bookings-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Guest</th><th>Check-In</th><th>Check-Out</th><th>Guests</th><th>Booked By</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  bookings.forEach((b) => {
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${b.first_name} ${b.last_name}</td>
        <td>${b.check_in_date}</td>
        <td>${b.check_out_date}</td>
        <td>${b.quantity}</td>
        <td>${b.username}</td>
        <td>
          <button type="button" class="btn btn-primary btn-sm btn-assign">Assign Room</button>
          <button type="button" class="btn btn-info btn-sm btn-manage">Manage / Bill</button>
          <button type="button" class="btn btn-danger btn-sm btn-cancel">Cancel</button>
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-assign").addEventListener("click", () => assignRoomModal(b.booking_id, displayBookings));
    row.querySelector(".btn-manage").addEventListener("click", () => bookingDetailsModal(b.booking_id, () => { displayBookings(); displayStatements(); displayRooms(); }));
    row.querySelector(".btn-cancel").addEventListener("click", () => cancelBookingModal(b.booking_id, displayBookings));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const insertBooking = async () => {
  const loggedInUser = JSON.parse(sessionStorage.getItem("loggedInUser"));
  const jsonData = {
    guestId: document.getElementById("booking-guest").value,
    userId: loggedInUser.user_id,
    checkInDate: document.getElementById("booking-check-in").value,
    checkOutDate: document.getElementById("booking-check-out").value,
    quantity: document.getElementById("booking-quantity").value,
  };

  const formData = new FormData();
  formData.append("operation", "insertBooking");
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/booking.php`, method: "POST", data: formData });

  if (response.data && response.data != 0) {
    displayBookings();
    alert("Booking created! Now assign a room to it from the list below.");
  } else {
    alert("ERROR");
  }
};


const displayStatements = async () => {
  const response = await axios.get(`${baseApiUrl}/billing_statement.php`, { params: { operation: "getAllStatements" } });
  if (response.status == 200) {
    displayStatementsTable(response.data);
  } else {
    alert("Error!");
  }
};

const displayStatementsTable = (statements) => {
  const tableDiv = document.getElementById("statements-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Guest</th><th>Statement Date</th><th>Amount Due</th><th>Amount Paid</th><th>Balance</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  statements.forEach((s) => {
    const balance = Number(s.amount_due) - Number(s.amount_paid);
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${s.first_name} ${s.last_name}</td>
        <td>${s.statement_date}</td>
        <td>${s.amount_due}</td>
        <td>${s.amount_paid}</td>
        <td>${balance.toFixed(2)}</td>
        <td><button type="button" class="btn btn-primary btn-sm btn-view">View / Pay</button></td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-view").addEventListener("click", () => payStatementModal(s.statement_id, displayStatements));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};


const displayRoomStatusOptions = async () => {
  const response = await axios.get(`${baseApiUrl}/room_status.php`, { params: { operation: "getRoomStatuses" } });
  if (response.status == 200) {
    roomStatuses = response.data;
    const select = document.getElementById("hk-room-status");
    select.innerHTML = "";
    roomStatuses.forEach((s) => {
      let option = document.createElement("option");
      option.innerText = s.room_status;
      option.value = s.room_status_id;
      select.appendChild(option);
    });
    displayRoomStatusesTable(roomStatuses);
  }
};

const displayRoomStatusesTable = (list) => {
  const tableDiv = document.getElementById("room-statuses-table-div");
  if (!tableDiv) return;
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Status</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((s) => {
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${s.room_status}</td>
        <td>
          <button type="button" class="btn btn-success btn-sm btn-edit">Edit</button>
          <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-edit").addEventListener("click", () => editRoomStatus(s));
    row.querySelector(".btn-delete").addEventListener("click", () => deleteRoomStatus(s.room_status_id));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const editRoomStatus = (s) => {
  editingRoomStatusId = s.room_status_id;
  document.getElementById("room-status-name").value = s.room_status;
};

const submitRoomStatus = async () => {
  const jsonData = { roomStatus: document.getElementById("room-status-name").value };

  const operation = editingRoomStatusId ? "updateRoomStatus" : "insertRoomStatus";
  if (editingRoomStatusId) jsonData.roomStatusId = editingRoomStatusId;

  const formData = new FormData();
  formData.append("operation", operation);
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/room_status.php`, method: "POST", data: formData });

  if (response.data == 1) {
    editingRoomStatusId = null;
    document.getElementById("room-status-name").value = "";
    displayRoomStatusOptions();
  } else {
    alert("ERROR");
  }
};

const deleteRoomStatus = async (roomStatusId) => {
  if (!confirm("Delete this room status?")) return;
  const params = { operation: "deleteRoomStatus", json: JSON.stringify({ roomStatusId }) };
  const response = await axios.get(`${baseApiUrl}/room_status.php`, { params });
  if (response.data == 1) {
    displayRoomStatusOptions();
  } else if (response.data == -1) {
    alert("This status cannot be deleted because it is still used by existing rooms or housekeeping records.");
  } else {
    alert("ERROR");
  }
};

const displayHousekeepingRoomOptions = () => {
  const select = document.getElementById("hk-room");
  if (!select) return;
  select.innerHTML = "";
  rooms.forEach((r) => {
    let option = document.createElement("option");
    option.innerText = `${r.room_number} (${r.room_type_name})`;
    option.value = r.room_id;
    select.appendChild(option);
  });
};

const displayHousekeeping = async () => {
  const response = await axios.get(`${baseApiUrl}/housekeeping.php`, { params: { operation: "getAllHousekeeping" } });
  if (response.status == 200) {
    displayHousekeepingTable(response.data);
  } else {
    alert("Error!");
  }
};

const displayHousekeepingTable = (list) => {
  const tableDiv = document.getElementById("housekeeping-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Room</th><th>Status Logged</th><th>New Room Status</th><th>Logged By</th><th>Active</th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((h) => {
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${h.room_number}</td>
        <td>${h.housekeeping_status}</td>
        <td>${h.room_status}</td>
        <td>${h.username}</td>
        <td>${h.is_active == 1 ? "Yes" : "No"}</td>
      `;
    tbody.appendChild(row);
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const insertHousekeeping = async () => {
  const loggedInUser = JSON.parse(sessionStorage.getItem("loggedInUser"));
  const jsonData = {
    userId: loggedInUser.user_id,
    roomId: document.getElementById("hk-room").value,
    housekeepingStatus: document.getElementById("hk-status").value,
    roomStatusId: document.getElementById("hk-room-status").value,
    isActive: 1,
  };

  const formData = new FormData();
  formData.append("operation", "insertHousekeeping");
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/housekeeping.php`, method: "POST", data: formData });

  if (response.data == 1) {
    displayHousekeeping();
    displayRooms();
    alert("Housekeeping update logged!");
  } else {
    alert("ERROR");
  }
};


const displayRoles = async () => {
  const response = await axios.get(`${baseApiUrl}/role.php`, { params: { operation: "getRoles" } });
  if (response.status == 200) {
    roles = response.data;
    const select = document.getElementById("user-role");
    select.innerHTML = "";
    roles.forEach((r) => {
      let option = document.createElement("option");
      option.innerText = r.role_type;
      option.value = r.role_id;
      select.appendChild(option);
    });
    displayRolesTable(roles);
  }

  const permResponse = await axios.get(`${baseApiUrl}/role.php`, { params: { operation: "getRolePermissions" } });
  if (permResponse.status == 200) {
    rolePermissions = Array.isArray(permResponse.data) ? permResponse.data : [];
  }
};


const displayRolesTable = (list) => {
  const tableDiv = document.getElementById("roles-table-div");
  if (!tableDiv) return;
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Role</th><th>Description</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((r) => {
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${r.role_type}</td>
        <td>${r.role_description ?? ""}</td>
        <td>
          <button type="button" class="btn btn-success btn-sm btn-edit">Edit</button>
          <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-edit").addEventListener("click", () => editRole(r));
    row.querySelector(".btn-delete").addEventListener("click", () => deleteRole(r.role_id));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const editRole = (r) => {
  editingRoleId = r.role_id;
  document.getElementById("role-type").value = r.role_type;
  document.getElementById("role-description").value = r.role_description ?? "";
  const assigned = rolePermissions.filter((p) => p.role_id == r.role_id).map((p) => p.feature_key);
  const isAdminRole = r.role_type === "Administrator";
  document.querySelectorAll(".role-permission-checkbox").forEach((c) => {
    c.checked = isAdminRole || assigned.includes(c.value);
  });
};

const isRoleOpSuccess = (data) => (typeof data === "number" ? data === 1 : !!(data && typeof data === "object" && data.success == 1));
const roleOpErrorMessage = (data) => {
  if (data && typeof data === "object" && data.error) return data.error;
  if (typeof data === "string" && data.trim()) return "Raw server response: " + data.trim().slice(0, 600);
  if (data === 0) return "The server rejected the request (check that role.php on your server matches the latest version, and that role_id was sent correctly).";
  return "Unexpected response from server: " + JSON.stringify(data);
};

const submitRole = async () => {
  const roleType = document.getElementById("role-type").value;
  const jsonData = {
    roleType,
    roleDescription: document.getElementById("role-description").value,
  };
  const selectedPermissions = Array.from(document.querySelectorAll(".role-permission-checkbox:checked")).map((c) => c.value);

  const operation = editingRoleId ? "updateRole" : "insertRole";
  if (editingRoleId) jsonData.roleId = editingRoleId;

  const formData = new FormData();
  formData.append("operation", operation);
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/role.php`, method: "POST", data: formData });

  if (isRoleOpSuccess(response.data)) {
    await displayRoles();
    const roleId = editingRoleId ?? roles.find((r) => r.role_type === roleType)?.role_id;
    if (roleId) {
      const permResult = await saveRolePermissions(roleId, selectedPermissions);
      if (!isRoleOpSuccess(permResult)) {
        alert("Role was saved, but Allowed Tabs failed to save: " + roleOpErrorMessage(permResult));
      }
    }

    editingRoleId = null;
    document.getElementById("role-type").value = "";
    document.getElementById("role-description").value = "";
    document.querySelectorAll(".role-permission-checkbox").forEach((c) => (c.checked = false));
    displayRoles();
  } else {
    alert("ERROR: " + roleOpErrorMessage(response.data));
  }
};

const saveRolePermissions = async (roleId, permissions) => {
  const formData = new FormData();
  formData.append("operation", "setRolePermissions");
  formData.append("json", JSON.stringify({ roleId, permissions }));
  const response = await axios({ url: `${baseApiUrl}/role.php`, method: "POST", data: formData });
  return response.data;
};

const deleteRole = async (roleId) => {
  if (!confirm("Delete this role?")) return;
  const params = { operation: "deleteRole", json: JSON.stringify({ roleId }) };
  const response = await axios.get(`${baseApiUrl}/role.php`, { params });
  if (response.data == 1) {
    displayRoles();
  } else if (response.data == -1) {
    alert("This role cannot be deleted because it is still assigned to existing users.");
  } else {
    alert("ERROR");
  }
};

const displayUsers = async () => {
  const response = await axios.get(`${baseApiUrl}/user.php`, { params: { operation: "getAllUsers" } });
  if (response.status == 200) {
    displayUsersTable(response.data);
  } else {
    alert("Error!");
  }
};

const displayUsersTable = (list) => {
  const tableDiv = document.getElementById("users-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Status</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((u) => {
    const isActive = u.user_status === "Active";
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${u.first_name} ${u.last_name}</td>
        <td>${u.username}</td>
        <td>${u.role_type}</td>
        <td>${u.user_status}</td>
        <td>
          <button type="button" class="btn btn-success btn-sm btn-edit">Edit</button>
          <button type="button" class="btn btn-warning btn-sm btn-reset">Reset Pass</button>
          ${isActive
            ? `<button type="button" class="btn btn-danger btn-sm btn-deactivate">Deactivate</button>`
            : `<button type="button" class="btn btn-secondary btn-sm btn-reactivate">Reactivate</button>`}
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-edit").addEventListener("click", () => editUser(u));
    row.querySelector(".btn-reset").addEventListener("click", () => resetPasswordModal(u.user_id));
    const deactivateBtn = row.querySelector(".btn-deactivate");
    if (deactivateBtn) deactivateBtn.addEventListener("click", () => deactivateUserModal(u.user_id, displayUsers));
    const reactivateBtn = row.querySelector(".btn-reactivate");
    if (reactivateBtn) reactivateBtn.addEventListener("click", () => reactivateUser(u.user_id, displayUsers));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const editUser = (u) => {
  editingUserId = u.user_id;
  document.getElementById("user-first-name").value = u.first_name;
  document.getElementById("user-last-name").value = u.last_name;
  document.getElementById("user-username").value = u.username;
  document.getElementById("user-email").value = u.email ?? "";
  document.getElementById("user-role").value = u.role_id;
  document.getElementById("user-status").value = u.user_status;
  document.getElementById("user-password").value = "";
};

const submitUser = async () => {
  const jsonData = {
    firstName: document.getElementById("user-first-name").value,
    lastName: document.getElementById("user-last-name").value,
    username: document.getElementById("user-username").value,
    email: document.getElementById("user-email").value,
    roleId: document.getElementById("user-role").value,
    userStatus: document.getElementById("user-status").value,
  };

  let operation = "insertUser";
  if (editingUserId) {
    operation = "updateUser";
    jsonData.userId = editingUserId;
  } else {
    jsonData.password = document.getElementById("user-password").value;
  }

  const formData = new FormData();
  formData.append("operation", operation);
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/user.php`, method: "POST", data: formData });

  if (response.data == 1) {
    editingUserId = null;
    document.getElementById("user-first-name").value = "";
    document.getElementById("user-last-name").value = "";
    document.getElementById("user-username").value = "";
    document.getElementById("user-email").value = "";
    document.getElementById("user-password").value = "";
    displayUsers();
  } else {
    alert("ERROR");
  }
};


const displayPaymentTypes = async () => {
  const response = await axios.get(`${baseApiUrl}/payment_type.php`, { params: { operation: "getPaymentTypes" } });
  if (response.status == 200) {
    displayPaymentTypesTable(response.data);
  }
};

const displayPaymentTypesTable = (list) => {
  const tableDiv = document.getElementById("payment-types-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Type</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((pt) => {
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${pt.payment_type_name}</td>
        <td>
          <button type="button" class="btn btn-success btn-sm btn-edit">Edit</button>
          <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-edit").addEventListener("click", () => editPaymentType(pt));
    row.querySelector(".btn-delete").addEventListener("click", () => deletePaymentType(pt.payment_type_id));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const editPaymentType = (pt) => {
  editingPaymentTypeId = pt.payment_type_id;
  document.getElementById("payment-type-name").value = pt.payment_type_name;
};

const submitPaymentType = async () => {
  const jsonData = { paymentTypeName: document.getElementById("payment-type-name").value };

  const operation = editingPaymentTypeId ? "updatePaymentType" : "insertPaymentType";
  if (editingPaymentTypeId) jsonData.paymentTypeId = editingPaymentTypeId;

  const formData = new FormData();
  formData.append("operation", operation);
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/payment_type.php`, method: "POST", data: formData });

  if (response.data == 1) {
    editingPaymentTypeId = null;
    document.getElementById("payment-type-name").value = "";
    displayPaymentTypes();
  } else {
    alert("ERROR");
  }
};

const deletePaymentType = async (paymentTypeId) => {
  if (!confirm("Delete this payment type?")) return;
  const params = { operation: "deletePaymentType", json: JSON.stringify({ paymentTypeId }) };
  const response = await axios.get(`${baseApiUrl}/payment_type.php`, { params });
  if (response.data == 1) {
    displayPaymentTypes();
  } else if (response.data == -1) {
    alert("This payment type cannot be deleted because it is used by existing payments.");
  } else {
    alert("ERROR");
  }
};

const displayPaymentStatuses = async () => {
  const response = await axios.get(`${baseApiUrl}/payment_status.php`, { params: { operation: "getPaymentStatuses" } });
  if (response.status == 200) {
    displayPaymentStatusesTable(response.data);
  }
};

const displayPaymentStatusesTable = (list) => {
  const tableDiv = document.getElementById("payment-statuses-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Status</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((ps) => {
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${ps.status_name}</td>
        <td>
          <button type="button" class="btn btn-success btn-sm btn-edit">Edit</button>
          <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-edit").addEventListener("click", () => editPaymentStatus(ps));
    row.querySelector(".btn-delete").addEventListener("click", () => deletePaymentStatus(ps.payment_status_id));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const editPaymentStatus = (ps) => {
  editingPaymentStatusId = ps.payment_status_id;
  document.getElementById("payment-status-name").value = ps.status_name;
};

const submitPaymentStatus = async () => {
  const jsonData = { statusName: document.getElementById("payment-status-name").value };

  const operation = editingPaymentStatusId ? "updatePaymentStatus" : "insertPaymentStatus";
  if (editingPaymentStatusId) jsonData.paymentStatusId = editingPaymentStatusId;

  const formData = new FormData();
  formData.append("operation", operation);
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/payment_status.php`, method: "POST", data: formData });

  if (response.data == 1) {
    editingPaymentStatusId = null;
    document.getElementById("payment-status-name").value = "";
    displayPaymentStatuses();
  } else {
    alert("ERROR");
  }
};

const deletePaymentStatus = async (paymentStatusId) => {
  if (!confirm("Delete this payment status?")) return;
  const params = { operation: "deletePaymentStatus", json: JSON.stringify({ paymentStatusId }) };
  const response = await axios.get(`${baseApiUrl}/payment_status.php`, { params });
  if (response.data == 1) {
    displayPaymentStatuses();
  } else if (response.data == -1) {
    alert("This status cannot be deleted because it is used by existing payments.");
  } else {
    alert("ERROR");
  }
};


const displayChargeCategories = async () => {
  const response = await axios.get(`${baseApiUrl}/charge_category.php`, { params: { operation: "getChargeCategories" } });
  if (response.status == 200) {
    chargeCategories = response.data;
    displayChargeCategoriesTable(chargeCategories);
    populateChargeCategorySelect();
  }
};

const populateChargeCategorySelect = () => {
  const select = document.getElementById("service-type-charge-category");
  if (!select) return;
  select.innerHTML = "";
  chargeCategories.forEach((cc) => {
    let option = document.createElement("option");
    option.innerText = cc.charge_category;
    option.value = cc.charge_category_id;
    select.appendChild(option);
  });
};

const displayChargeCategoriesTable = (list) => {
  const tableDiv = document.getElementById("charge-categories-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Category</th><th>Type</th><th>Price</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((cc) => {
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${cc.charge_category}</td>
        <td>${cc.charge_type ?? ""}</td>
        <td>${cc.default_price}</td>
        <td>
          <button type="button" class="btn btn-success btn-sm btn-edit">Edit</button>
          <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-edit").addEventListener("click", () => editChargeCategory(cc));
    row.querySelector(".btn-delete").addEventListener("click", () => deleteChargeCategory(cc.charge_category_id));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const editChargeCategory = (cc) => {
  editingChargeCategoryId = cc.charge_category_id;
  document.getElementById("charge-category-name").value = cc.charge_category;
  document.getElementById("charge-category-type").value = cc.charge_type ?? "";
  document.getElementById("charge-category-price").value = cc.default_price;
  editingChargeCategoryTaxable = cc.is_taxable;
};

const submitChargeCategory = async () => {
  const jsonData = {
    chargeCategory: document.getElementById("charge-category-name").value,
    chargeType: document.getElementById("charge-category-type").value,
    defaultPrice: document.getElementById("charge-category-price").value,
    isTaxable: editingChargeCategoryId ? editingChargeCategoryTaxable : 1,
  };

  const operation = editingChargeCategoryId ? "updateChargeCategory" : "insertChargeCategory";
  if (editingChargeCategoryId) jsonData.chargeCategoryId = editingChargeCategoryId;

  const formData = new FormData();
  formData.append("operation", operation);
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/charge_category.php`, method: "POST", data: formData });

  if (response.data == 1) {
    editingChargeCategoryId = null;
    document.getElementById("charge-category-name").value = "";
    document.getElementById("charge-category-type").value = "";
    document.getElementById("charge-category-price").value = "";
    displayChargeCategories();
  } else {
    alert("ERROR");
  }
};

const deleteChargeCategory = async (chargeCategoryId) => {
  if (!confirm("Delete this charge category?")) return;
  const params = { operation: "deleteChargeCategory", json: JSON.stringify({ chargeCategoryId }) };
  const response = await axios.get(`${baseApiUrl}/charge_category.php`, { params });
  if (response.data == 1) {
    displayChargeCategories();
  } else if (response.data == -1) {
    alert("This category cannot be deleted because it is used by existing service types.");
  } else {
    alert("ERROR");
  }
};

const displayServiceTypes = async () => {
  const response = await axios.get(`${baseApiUrl}/service_type.php`, { params: { operation: "getServiceTypes" } });
  if (response.status == 200) {
    displayServiceTypesTable(response.data);
  }
};

const displayServiceTypesTable = (list) => {
  const tableDiv = document.getElementById("service-types-table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `<thead><tr><th>Service</th><th>Category</th><th>Fee</th><th></th></tr></thead>`;

  const tbody = document.createElement("tbody");
  list.forEach((st) => {
    let row = document.createElement("tr");
    row.innerHTML = `
        <td>${st.service_type}</td>
        <td>${st.charge_category}</td>
        <td>${st.service_fee}</td>
        <td>
          <button type="button" class="btn btn-success btn-sm btn-edit">Edit</button>
          <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
        </td>
      `;
    tbody.appendChild(row);
    row.querySelector(".btn-edit").addEventListener("click", () => editServiceType(st));
    row.querySelector(".btn-delete").addEventListener("click", () => deleteServiceType(st.service_type_id));
  });
  table.appendChild(tbody);
  tableDiv.appendChild(table);
};

const editServiceType = (st) => {
  editingServiceTypeId = st.service_type_id;
  document.getElementById("service-type-charge-category").value = st.charge_category_id;
  document.getElementById("service-type-name").value = st.service_type;
  document.getElementById("service-type-fee").value = st.service_fee;
};

const submitServiceType = async () => {
  const jsonData = {
    chargeCategoryId: document.getElementById("service-type-charge-category").value,
    serviceType: document.getElementById("service-type-name").value,
    serviceFee: document.getElementById("service-type-fee").value,
  };

  const operation = editingServiceTypeId ? "updateServiceType" : "insertServiceType";
  if (editingServiceTypeId) jsonData.serviceTypeId = editingServiceTypeId;

  const formData = new FormData();
  formData.append("operation", operation);
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/service_type.php`, method: "POST", data: formData });

  if (response.data == 1) {
    editingServiceTypeId = null;
    document.getElementById("service-type-name").value = "";
    document.getElementById("service-type-fee").value = "";
    displayServiceTypes();
  } else {
    alert("ERROR");
  }
};

const deleteServiceType = async (serviceTypeId) => {
  if (!confirm("Delete this service type?")) return;
  const params = { operation: "deleteServiceType", json: JSON.stringify({ serviceTypeId }) };
  const response = await axios.get(`${baseApiUrl}/service_type.php`, { params });
  if (response.data == 1) {
    displayServiceTypes();
  } else if (response.data == -1) {
    alert("This service type cannot be deleted because it is used by existing charges.");
  } else {
    alert("ERROR");
  }
};