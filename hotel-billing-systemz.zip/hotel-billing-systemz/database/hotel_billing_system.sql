-- =====================================================================
-- HOTEL BILLING SYSTEM DATABASE
-- Structured to follow the provided ERD exactly (entity names & attributes)
-- =====================================================================

CREATE DATABASE IF NOT EXISTS hotel_billing_system;
USE hotel_billing_system;

-- ---------------------------------------------------------------------
-- ROLE
-- ---------------------------------------------------------------------
CREATE TABLE role (
  role_id INT AUTO_INCREMENT PRIMARY KEY,
  role_type VARCHAR(50) NOT NULL,
  role_description VARCHAR(255)
);

-- ---------------------------------------------------------------------
-- ROLE_PERMISSION
-- ---------------------------------------------------------------------
-- Which feature tabs a role is allowed to see/use. Administrator always
-- has full access regardless of this table (enforced in the app code).
CREATE TABLE role_permission (
  role_permission_id INT AUTO_INCREMENT PRIMARY KEY,
  role_id INT NOT NULL,
  feature_key VARCHAR(50) NOT NULL,
  FOREIGN KEY (role_id) REFERENCES role(role_id) ON DELETE CASCADE,
  UNIQUE KEY uq_role_feature (role_id, feature_key)
);

-- ---------------------------------------------------------------------
-- USER
-- ---------------------------------------------------------------------
CREATE TABLE user (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  role_id INT NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  email VARCHAR(100),
  user_status VARCHAR(20) NOT NULL DEFAULT 'Active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (role_id) REFERENCES role(role_id)
);

-- ---------------------------------------------------------------------
-- GUEST_TYPE
-- ---------------------------------------------------------------------
CREATE TABLE guest_type (
  guest_type_id INT AUTO_INCREMENT PRIMARY KEY,
  guest_type VARCHAR(50) NOT NULL,
  discount_percentage DECIMAL(5,2) NOT NULL DEFAULT 0,
  privilege VARCHAR(255)
);

-- ---------------------------------------------------------------------
-- GUEST
-- ---------------------------------------------------------------------
CREATE TABLE guest (
  guest_id INT AUTO_INCREMENT PRIMARY KEY,
  guest_type_id INT NOT NULL,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  contact_number VARCHAR(20),
  email VARCHAR(100),
  address VARCHAR(255),
  date_registered DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (guest_type_id) REFERENCES guest_type(guest_type_id)
);

-- ---------------------------------------------------------------------
-- ROOM_TYPE
-- ---------------------------------------------------------------------
CREATE TABLE room_type (
  room_type_id INT AUTO_INCREMENT PRIMARY KEY,
  room_type_name VARCHAR(50) NOT NULL,
  room_type_description VARCHAR(255),
  capacity INT NOT NULL DEFAULT 1,
  rate_per_night DECIMAL(10,2) NOT NULL DEFAULT 0,
  effective_from DATE,
  effective_to DATE
);

-- ---------------------------------------------------------------------
-- FLOOR
-- ---------------------------------------------------------------------
CREATE TABLE floor (
  floor_id INT AUTO_INCREMENT PRIMARY KEY,
  floor_number INT NOT NULL,
  floor_name VARCHAR(50)
);

-- ---------------------------------------------------------------------
-- ROOM_STATUS
-- ---------------------------------------------------------------------
CREATE TABLE room_status (
  room_status_id INT AUTO_INCREMENT PRIMARY KEY,
  room_status VARCHAR(50) NOT NULL
);

-- ---------------------------------------------------------------------
-- ROOMS
-- ---------------------------------------------------------------------
CREATE TABLE rooms (
  room_id INT AUTO_INCREMENT PRIMARY KEY,
  room_type_id INT NOT NULL,
  floor_id INT NOT NULL,
  room_status_id INT NOT NULL,
  room_number VARCHAR(10) NOT NULL,
  FOREIGN KEY (room_type_id) REFERENCES room_type(room_type_id),
  FOREIGN KEY (floor_id) REFERENCES floor(floor_id),
  FOREIGN KEY (room_status_id) REFERENCES room_status(room_status_id)
);

-- ---------------------------------------------------------------------
-- HOUSEKEEPING
-- ---------------------------------------------------------------------
CREATE TABLE housekeeping (
  housekeep_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  room_status_id INT NOT NULL,
  room_id INT NOT NULL,
  housekeeping_status VARCHAR(50) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  FOREIGN KEY (user_id) REFERENCES user(user_id),
  FOREIGN KEY (room_status_id) REFERENCES room_status(room_status_id),
  FOREIGN KEY (room_id) REFERENCES rooms(room_id)
);

-- ---------------------------------------------------------------------
-- BOOKING
-- ---------------------------------------------------------------------
CREATE TABLE booking (
  booking_id INT AUTO_INCREMENT PRIMARY KEY,
  guest_id INT NOT NULL,
  user_id INT NOT NULL,
  booking_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  check_in_date DATE NOT NULL,
  check_out_date DATE NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  FOREIGN KEY (guest_id) REFERENCES guest(guest_id),
  FOREIGN KEY (user_id) REFERENCES user(user_id)
);

-- ---------------------------------------------------------------------
-- BOOKING_ROOM
-- ---------------------------------------------------------------------
CREATE TABLE booking_room (
  booking_room_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  room_id INT NOT NULL,
  rate_charged DECIMAL(10,2) NOT NULL,
  booking_status VARCHAR(50) NOT NULL DEFAULT 'Reserved',
  date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES booking(booking_id),
  FOREIGN KEY (room_id) REFERENCES rooms(room_id)
);

-- ---------------------------------------------------------------------
-- CHARGE_CATEGORY
-- ---------------------------------------------------------------------
CREATE TABLE charge_category (
  charge_category_id INT AUTO_INCREMENT PRIMARY KEY,
  charge_category VARCHAR(50) NOT NULL,
  charge_type VARCHAR(50),
  default_price DECIMAL(10,2) NOT NULL DEFAULT 0,
  is_taxable TINYINT(1) NOT NULL DEFAULT 1
);

-- ---------------------------------------------------------------------
-- SERVICE_TYPE
-- ---------------------------------------------------------------------
CREATE TABLE service_type (
  service_type_id INT AUTO_INCREMENT PRIMARY KEY,
  charge_category_id INT NOT NULL,
  service_type VARCHAR(50) NOT NULL,
  service_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (charge_category_id) REFERENCES charge_category(charge_category_id)
);

-- ---------------------------------------------------------------------
-- BILL
-- ---------------------------------------------------------------------
CREATE TABLE bill (
  bill_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  bill_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  subtotal_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (booking_id) REFERENCES booking(booking_id)
);

-- ---------------------------------------------------------------------
-- CHARGE
-- ---------------------------------------------------------------------
CREATE TABLE charge (
  charge_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  bill_id INT NULL,
  service_type_id INT NOT NULL,
  price_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  unit_price DECIMAL(10,2) NOT NULL DEFAULT 0,
  tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  number_of_guests INT NOT NULL DEFAULT 1,
  total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (booking_id) REFERENCES booking(booking_id),
  FOREIGN KEY (bill_id) REFERENCES bill(bill_id),
  FOREIGN KEY (service_type_id) REFERENCES service_type(service_type_id)
);

-- ---------------------------------------------------------------------
-- BILLING STATEMENT
-- ---------------------------------------------------------------------
CREATE TABLE billing_statement (
  statement_id INT AUTO_INCREMENT PRIMARY KEY,
  bill_id INT NOT NULL,
  statement_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  amount_due DECIMAL(10,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (bill_id) REFERENCES bill(bill_id)
);

-- ---------------------------------------------------------------------
-- PAYMENT_TYPE
-- ---------------------------------------------------------------------
CREATE TABLE payment_type (
  payment_type_id INT AUTO_INCREMENT PRIMARY KEY,
  payment_type_name VARCHAR(50) NOT NULL
);

-- ---------------------------------------------------------------------
-- PAYMENT_STATUS
-- ---------------------------------------------------------------------
CREATE TABLE payment_status (
  payment_status_id INT AUTO_INCREMENT PRIMARY KEY,
  status_name VARCHAR(50) NOT NULL
);

-- ---------------------------------------------------------------------
-- PAYMENT
-- ---------------------------------------------------------------------
CREATE TABLE payment (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  statement_id INT NOT NULL,
  payment_type_id INT NOT NULL,
  payment_status_id INT NOT NULL,
  payment_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  amount DECIMAL(10,2) NOT NULL,
  reference_number VARCHAR(100),
  FOREIGN KEY (statement_id) REFERENCES billing_statement(statement_id),
  FOREIGN KEY (payment_type_id) REFERENCES payment_type(payment_type_id),
  FOREIGN KEY (payment_status_id) REFERENCES payment_status(payment_status_id)
);

-- ---------------------------------------------------------------------
-- PAYMENT_AUDIT
-- ---------------------------------------------------------------------
CREATE TABLE payment_audit (
  audit_id INT AUTO_INCREMENT PRIMARY KEY,
  payment_id INT NOT NULL,
  user_id INT NOT NULL,
  action VARCHAR(100) NOT NULL,
  timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (payment_id) REFERENCES payment(payment_id),
  FOREIGN KEY (user_id) REFERENCES user(user_id)
);

-- =====================================================================
-- SEED / LOOKUP DATA
-- =====================================================================

INSERT INTO role (role_type, role_description) VALUES
('Administrator', 'Full access to the system'),
('Front Desk Staff', 'Handles bookings, billing, and payments'),
('Housekeeping', 'Can only log room housekeeping status updates');

-- Administrator needs no rows here - it always has full access.
-- Front Desk Staff keeps its previous access (everything except Users/Settings).
-- Housekeeping can only see the Housekeeping tab.
INSERT INTO role_permission (role_id, feature_key) VALUES
(2, 'guests'), (2, 'rooms'), (2, 'bookings'), (2, 'billing'), (2, 'housekeeping'),
(3, 'housekeeping');

-- default admin account -> username: admin / password: admin123
INSERT INTO user (role_id, username, password, first_name, last_name, email, user_status) VALUES
(1, 'admin', '$2y$10$xjmY4XExmZDeuVR9P0G8ZuHsNJSCT8XV4s1XFARQwvYXLurMPVxby', 'System', 'Administrator', 'admin@hotel.com', 'Active');

INSERT INTO guest_type (guest_type, discount_percentage, privilege) VALUES
('Regular', 0.00, 'Standard rate'),
('Senior Citizen', 20.00, '20% discount per RA 9994'),
('PWD', 20.00, '20% discount per RA 10754'),
('VIP', 10.00, 'Loyalty member discount');

INSERT INTO room_status (room_status) VALUES
('Available'),
('Occupied'),
('Reserved'),
('Under Maintenance'),
('Retired');

INSERT INTO room_type (room_type_name, room_type_description, capacity, rate_per_night, effective_from, effective_to) VALUES
('Standard', 'Standard room with basic amenities', 2, 1500.00, CURDATE(), NULL),
('Deluxe', 'Deluxe room with city view', 2, 2500.00, CURDATE(), NULL),
('Suite', 'Suite with living area', 4, 4500.00, CURDATE(), NULL);

INSERT INTO floor (floor_number, floor_name) VALUES
(1, 'Ground Floor'),
(2, 'Second Floor'),
(3, 'Third Floor');

INSERT INTO rooms (room_type_id, floor_id, room_status_id, room_number) VALUES
(1, 1, 1, '101'),
(1, 1, 1, '102'),
(2, 2, 1, '201'),
(2, 2, 1, '202'),
(3, 3, 1, '301');

INSERT INTO payment_type (payment_type_name) VALUES
('Cash'),
('Credit Card'),
('GCash');

INSERT INTO payment_status (status_name) VALUES
('Pending'),
('Partially Paid'),
('Paid');

INSERT INTO charge_category (charge_category, charge_type, default_price, is_taxable) VALUES
('Food & Beverage', 'Room Service', 250.00, 1),
('Laundry', 'Service', 150.00, 1),
('Amenities', 'Minibar', 100.00, 1);

INSERT INTO service_type (charge_category_id, service_type, service_fee) VALUES
(1, 'Room Service - Breakfast', 250.00),
(2, 'Laundry Service', 150.00),
(3, 'Minibar Charge', 100.00);
