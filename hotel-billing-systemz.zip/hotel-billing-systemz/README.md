# Hotel Billing System

A PHP + PDO (MySQL) + Axios/Bootstrap hotel billing system, built with the same code
structure as your sample project (class-based API files with a `switch(operation)`
dispatcher, and a frontend that uses `axios` with `sessionStorage` + Bootstrap modals).

## Folder structure

```
hotel-billing-system/
  database/hotel_billing_system.sql   <- run this in phpMyAdmin/MySQL first
  api/                                <- PHP backend (one file per ERD entity)
  js/index.js, js/login.js            <- frontend controllers
  modules/                            <- view/update/delete/modal logic (like your view.js/update.js/delete.js)
  index.html                          <- main dashboard (requires login)
  login.html                          <- login page
```

## Setup (XAMPP / WAMP / Laragon style)

1. Copy the whole `hotel-billing-system` folder into your web server's root
   (e.g. `htdocs/hotel-billing-system`).
2. Start Apache and MySQL.
3. Open phpMyAdmin and import `database/hotel_billing_system.sql`.
   This creates the `hotel_billing_system` database with **every table from the ERD**,
   using the exact entity names and attributes shown in the diagram, plus seed data
   (roles, guest types, room types, floors, rooms, payment types/statuses, etc.).
4. Check `api/connection-pdo.php` — it already matches your sample
   (`localhost` / `root` / no password / `hotel_billing_system`). Adjust if your
   MySQL credentials differ.
5. In `js/index.js` and `js/login.js`, the `baseApiUrl` is set to
   `http://localhost/hotel-billing-system/api` — update this if you placed the
   folder somewhere else.
6. Open `http://localhost/hotel-billing-system/login.html` in your browser.

## Master File Module (Milestone 1)

Every lookup/master table now has a full Create-Read-Update-Delete interface,
reachable from the dashboard:

- **Guests tab** — Guest CRUD (with a Guest Type dropdown)
- **Rooms tab** — Room Type CRUD, Floor CRUD, Room CRUD
- **Users tab** (Administrator only) — User account CRUD, with role assignment
- **Settings tab** (Administrator only) — Guest Types, Roles, Room Statuses,
  Payment Types, Payment Statuses, Charge Categories, and Service Types, each
  with its own Add/Edit/Delete form and table

All of them read/write through the PDO API and are pre-populated with sample
data from `database/hotel_billing_system.sql`.

### Hard delete vs. soft delete

Each table's delete behavior was chosen based on whether the ERD gives it a
field to represent "inactive," and how heavily transaction tables depend on
it — no columns were added to the ERD to make this work:

| Table | Delete behavior | Why |
|---|---|---|
| `room_type` | **Soft** — "Delete" sets `effective_to = today` (Retire); "Reactivate" clears it | The ERD already gives this entity `effective_from`/`effective_to` for exactly this purpose, and it's referenced by `rooms` and historical bookings |
| `rooms` | **Soft** — "Delete" sets the room's `room_status_id` to a `Retired` status (Reactivate sets it back to `Available`) | Heavily referenced by `booking_room` and `housekeeping`; a `Retired` room status was added as a normal lookup value (not a schema change) |
| `user` | **Soft** — "Delete" sets `user_status = 'Inactive'` (blocks login); "Reactivate" sets it back to `Active` | The ERD already gives this entity a `user_status` column, and users are referenced by `booking`, `housekeeping`, and `payment_audit` |
| `guest`, `guest_type`, `role`, `floor`, `room_status`, `payment_type`, `payment_status`, `charge_category`, `service_type` | **Hard delete, guarded** — a normal `DELETE`, but if the row is still referenced elsewhere the foreign key stops it and the API returns a clear "still in use" result instead of a raw SQL error | None of these entities have a status/active column in the ERD, so once a row is no longer referenced anywhere, permanently removing it is safe and keeps the lookup tables clean |

## Default login

- **Username:** `admin`
- **Password:** `admin123`
- Role: Administrator (only Administrators can see the Users tab)

## How it works

- **Login** — `login.html`/`login.js` calls `api/user.php?operation=login`, which
  checks the hashed password and returns the user + role. The user is stored in
  `sessionStorage` (same pattern your sample used for `baseAPIUrl`), and every page
  checks for it before loading.
- **Guests** — register guests with a guest type (Regular / Senior / PWD / VIP),
  each with its own discount percentage, exactly like `GUEST` + `GUEST_TYPE` in the ERD.
- **Rooms** — manage Room Types, Floors, and Rooms (with Room Status).
- **Bookings** — create a booking for a guest, assign one or more rooms
  (`BOOKING_ROOM`), check guests in/out, add service charges (`CHARGE`,
  `SERVICE_TYPE`, `CHARGE_CATEGORY`), then "Generate Bill" to compute the
  subtotal/discount/tax/total (`BILL`) and automatically create a `BILLING_STATEMENT`.
- **Billing & Payments** — view a statement's balance and record payments
  (`PAYMENT`, `PAYMENT_TYPE`, `PAYMENT_STATUS`); every payment is logged to
  `PAYMENT_AUDIT`.
- **Housekeeping** — log a housekeeping status change for a room; this also
  updates the room's current `ROOM_STATUS`.
- **Users** (Administrator only) — add staff/admin accounts, assign roles, reset
  passwords, deactivate/delete accounts.

Nothing beyond what you asked for was added — no extra pages, libraries, or
features outside the ERD and the login system.
