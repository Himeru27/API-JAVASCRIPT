export const resetPasswordModal = (userId) => {
  const myModal = new bootstrap.Modal(document.getElementById("blank-modal"), {
    keyboard: true,
    backdrop: "static",
  });

  document.getElementById("blank-modal-title").innerText = "Reset Password";
  document.getElementById("blank-main-div").innerHTML = `
    <div class="col-md-12">
      <input type="password" id="reset-password" class="form-control" placeholder="New Password" />
    </div>
  `;

  const modalFooter = document.getElementById("blank-modal-footer");
  modalFooter.innerHTML = `
      <button type="button" class="btn btn-primary btn-sm w-100 btn-reset">RESET</button>
      <button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>
    `;

  modalFooter.querySelector(".btn-reset").addEventListener("click", async () => {
    const password = document.getElementById("reset-password").value;
    const formData = new FormData();
    formData.append("operation", "resetPassword");
    formData.append("json", JSON.stringify({ userId, password }));
    const response = await axios({ url: `${sessionStorage.baseAPIUrl}/user.php`, method: "POST", data: formData });

    if (response.data == 1) {
      alert("Password has been reset!");
      myModal.hide();
    } else {
      alert("ERROR");
    }
  });

  myModal.show();
};

// Soft delete: sets user_status to Inactive (see api/user.php -> deactivateUser).
// The account and its history (bookings, housekeeping logs, payment audits)
// are kept - the account just can no longer log in.
export const deactivateUserModal = async (userId, refreshDisplay) => {
  document.getElementById("blank-modal-title").innerText = "Confirm Deactivation";
  document.getElementById("blank-main-div").innerHTML = `<p>Deactivate this user account? They will no longer be able to log in, but their records (bookings, housekeeping logs, payments) are kept.</p>`;

  const modalFooter = document.getElementById("blank-modal-footer");
  modalFooter.innerHTML = `
      <div class="btn-group" role="group">
        <button type="button" class="btn btn-danger btn-sm w-100 me-2 btn-deactivate">Deactivate</button>
        <button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>
      </div>
   `;

  const myModal = new bootstrap.Modal(document.getElementById("blank-modal"), {
    keyboard: true,
    backdrop: "static",
  });

  modalFooter.querySelector(".btn-deactivate").addEventListener("click", async () => {
    const formData = new FormData();
    formData.append("operation", "deactivateUser");
    formData.append("json", JSON.stringify({ userId }));
    const response = await axios({ url: `${sessionStorage.baseAPIUrl}/user.php`, method: "POST", data: formData });

    if (response.data == 1) {
      refreshDisplay();
      alert("User has been deactivated!");
      myModal.hide();
    } else {
      alert("ERROR");
    }
  });

  myModal.show();
};

export const reactivateUser = async (userId, refreshDisplay) => {
  const formData = new FormData();
  formData.append("operation", "reactivateUser");
  formData.append("json", JSON.stringify({ userId }));
  const response = await axios({ url: `${sessionStorage.baseAPIUrl}/user.php`, method: "POST", data: formData });

  if (response.data == 1) {
    refreshDisplay();
  } else {
    alert("ERROR");
  }
};
