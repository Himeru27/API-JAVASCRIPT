export const viewGuestModal = async (guestId) => {
  document.getElementById("blank-modal-title").innerText = "Guest Details";

  const guest = await getGuestDetails(guestId);
  let myHtml = `
        <table class="table table-sm">
          <tr><td>First Name</td><td>${guest[0].first_name}</td></tr>
          <tr><td>Last Name</td><td>${guest[0].last_name}</td></tr>
          <tr><td>Contact Number</td><td>${guest[0].contact_number}</td></tr>
          <tr><td>Email</td><td>${guest[0].email}</td></tr>
          <tr><td>Address</td><td>${guest[0].address}</td></tr>
          <tr><td>Guest Type</td><td>${guest[0].guest_type}</td></tr>
          <tr><td>Date Registered</td><td>${guest[0].date_registered}</td></tr>
        </table>
    `;
  document.getElementById("blank-main-div").innerHTML = myHtml;

  const modalFooter = document.getElementById("blank-modal-footer");
  modalFooter.innerHTML = `<button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>`;

  const myModal = new bootstrap.Modal(document.getElementById("blank-modal"), {
    keyboard: true,
    backdrop: "static",
  });
  myModal.show();
};

export const updateGuestModal = async (guestId, guestTypes, refreshDisplay) => {
  const myModal = new bootstrap.Modal(document.getElementById("blank-modal"), {
    keyboard: true,
    backdrop: "static",
  });

  document.getElementById("blank-modal-title").innerText = "Update Guest";

  const guest = await getGuestDetails(guestId);

  let myHtml = `
        <table class="table table-sm">
          <tr>
            <td>First Name</td>
            <td><input type="text" id="update-guest-first-name" class="form-control" value="${guest[0].first_name}" /></td>
          </tr>
          <tr>
            <td>Last Name</td>
            <td><input type="text" id="update-guest-last-name" class="form-control" value="${guest[0].last_name}" /></td>
          </tr>
          <tr>
            <td>Contact Number</td>
            <td><input type="text" id="update-guest-contact-number" class="form-control" value="${guest[0].contact_number}" /></td>
          </tr>
          <tr>
            <td>Email</td>
            <td><input type="email" id="update-guest-email" class="form-control" value="${guest[0].email}" /></td>
          </tr>
          <tr>
            <td>Address</td>
            <td><input type="text" id="update-guest-address" class="form-control" value="${guest[0].address}" /></td>
          </tr>
          <tr>
            <td>Guest Type</td>
            <td>${createGuestTypeSelect(guestTypes, guest[0].guest_type_id)}</td>
          </tr>
        </table>
    `;
  document.getElementById("blank-main-div").innerHTML = myHtml;

  const modalFooter = document.getElementById("blank-modal-footer");
  modalFooter.innerHTML = `
      <button type="button" class="btn btn-primary btn-sm w-100 btn-update">UPDATE</button>
      <button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>
    `;

  modalFooter.querySelector(".btn-update").addEventListener("click", async () => {
    if (await updateGuest(guestId) == 1) {
      refreshDisplay();
      alert("Guest record has been successfully updated!");
      myModal.hide();
    } else {
      alert("ERROR!");
    }
  });

  myModal.show();
};

export const deleteGuestModal = async (guestId, refreshDisplay) => {
  document.getElementById("blank-modal-title").innerText = "Confirm Delete";

  const guest = await getGuestDetails(guestId);
  let myHtml = `
        <table class="table table-sm">
          <tr><td>First Name</td><td>${guest[0].first_name}</td></tr>
          <tr><td>Last Name</td><td>${guest[0].last_name}</td></tr>
          <tr><td>Guest Type</td><td>${guest[0].guest_type}</td></tr>
        </table>
    `;
  document.getElementById("blank-main-div").innerHTML = myHtml;

  const modalFooter = document.getElementById("blank-modal-footer");
  modalFooter.innerHTML = `
      <div class="btn-group" role="group">
        <button type="button" class="btn btn-danger btn-sm w-100 me-2 btn-delete">Delete</button>
        <button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>
      </div>
   `;

  const myModal = new bootstrap.Modal(document.getElementById("blank-modal"), {
    keyboard: true,
    backdrop: "static",
  });

  modalFooter.querySelector(".btn-delete").addEventListener("click", async () => {
    const result = await deleteGuest(guestId);
    if (result == 1) {
      refreshDisplay();
      alert("Guest has been deleted!");
      myModal.hide();
    } else if (result == -1) {
      alert("This guest cannot be deleted because they already have booking records.");
    } else {
      alert("ERROR");
    }
  });

  myModal.show();
};

const createGuestTypeSelect = (guestTypes, guestTypeId) => {
  let myHtml = `<select id="update-guest-type" class="form-select">`;
  guestTypes.forEach((type) => {
    let selected = guestTypeId == type.guest_type_id ? "selected" : "";
    myHtml += `<option value="${type.guest_type_id}" ${selected}>${type.guest_type}</option>`;
  });
  myHtml += "</select>";
  return myHtml;
};

const getGuestDetails = async (guestId) => {
  const params = {
    operation: "getGuest",
    json: JSON.stringify({ guestId: guestId }),
  };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/guest.php`, { params });
  return response.data;
};

const updateGuest = async (guestId) => {
  const jsonData = {
    guestId: guestId,
    firstName: document.getElementById("update-guest-first-name").value,
    lastName: document.getElementById("update-guest-last-name").value,
    contactNumber: document.getElementById("update-guest-contact-number").value,
    email: document.getElementById("update-guest-email").value,
    address: document.getElementById("update-guest-address").value,
    guestTypeId: document.getElementById("update-guest-type").value,
  };

  const formData = new FormData();
  formData.append("operation", "updateGuest");
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({
    url: `${sessionStorage.baseAPIUrl}/guest.php`,
    method: "POST",
    data: formData,
  });
  return response.data;
};

const deleteGuest = async (guestId) => {
  const params = {
    operation: "deleteGuest",
    json: JSON.stringify({ guestId: guestId }),
  };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/guest.php`, { params });
  return response.data;
};
