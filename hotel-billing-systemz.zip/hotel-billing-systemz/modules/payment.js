export const payStatementModal = async (statementId, refreshDisplay) => {
  const myModal = bootstrap.Modal.getOrCreateInstance(document.getElementById("blank-modal"), {
    keyboard: true,
    backdrop: "static",
  });

  document.getElementById("blank-modal-title").innerText = "Billing Statement";

  const statement = await getStatement(statementId);
  const payments = await getPaymentsByStatement(statementId);
  const paymentTypes = await getPaymentTypes();

  const totalPaid = payments.reduce((sum, p) => sum + Number(p.amount), 0);
  const balance = Number(statement[0].total_amount) - totalPaid;

  let paymentRows = payments
    .map(
      (p) => `
      <tr>
        <td>${p.payment_date}</td>
        <td>${p.payment_type_name}</td>
        <td>${p.amount}</td>
        <td>${p.status_name}</td>
        <td>${p.reference_number ?? ""}</td>
      </tr>`
    )
    .join("");

  let paymentTypeOptions = paymentTypes.map((t) => `<option value="${t.payment_type_id}">${t.payment_type_name}</option>`).join("");

  document.getElementById("blank-main-div").innerHTML = `
    <div class="col-md-12">
      <table class="table table-sm">
        <tr><td>Guest</td><td>${statement[0].first_name} ${statement[0].last_name}</td></tr>
        <tr><td>Subtotal</td><td>${statement[0].subtotal_amount}</td></tr>
        <tr><td>Discount</td><td>${statement[0].discount_amount}</td></tr>
        <tr><td>Tax</td><td>${statement[0].tax_amount}</td></tr>
        <tr><td>Total Amount</td><td>${statement[0].total_amount}</td></tr>
        <tr><td>Balance</td><td><strong>${balance.toFixed(2)}</strong></td></tr>
      </table>

      <h6>Payment History</h6>
      <table class="table table-sm">
        <thead><tr><th>Date</th><th>Type</th><th>Amount</th><th>Status</th><th>Reference</th></tr></thead>
        <tbody>${paymentRows}</tbody>
      </table>

      ${
        balance > 0
          ? `
      <h6>Record Payment</h6>
      <div class="row">
        <div class="col-md-6"><input type="number" id="payment-amount" class="form-control" placeholder="Amount" /></div>
        <div class="col-md-6"><select id="payment-type" class="form-select">${paymentTypeOptions}</select></div>
      </div>
      <button type="button" class="btn btn-success w-100 mt-2 btn-pay">Record Payment</button>
      `
          : `<div class="alert alert-success">This statement has been fully paid.</div>`
      }
    </div>
  `;

  const modalFooter = document.getElementById("blank-modal-footer");
  modalFooter.innerHTML = `<button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>`;

  const btnPay = document.querySelector(".btn-pay");
  if (btnPay) {
    btnPay.addEventListener("click", async () => {
      const amount = document.getElementById("payment-amount").value;
      const paymentTypeId = document.getElementById("payment-type").value;

      if (Number(amount) > balance) {
        alert("ERROR - Payment amount cannot exceed the remaining balance. Please enter the exact amount due.");
        return;
      }

      const referenceNumber = generateReferenceNumber();

      if (await recordPayment(statementId, amount, paymentTypeId, referenceNumber) == 1) {
        refreshDisplay();
        alert("Payment recorded!");
        payStatementModal(statementId, refreshDisplay);
      } else {
        alert("ERROR");
      }
    });
  }

  myModal.show();
};

const generateReferenceNumber = () => {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 7).toUpperCase();
  return `REF-${timestamp}-${random}`;
};

const getStatement = async (statementId) => {
  const params = { operation: "getStatement", json: JSON.stringify({ statementId }) };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/billing_statement.php`, { params });
  return response.data;
};

const getPaymentsByStatement = async (statementId) => {
  const params = { operation: "getPaymentsByStatement", json: JSON.stringify({ statementId }) };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/payment.php`, { params });
  return response.data;
};

const getPaymentTypes = async () => {
  const params = { operation: "getPaymentTypes" };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/payment_type.php`, { params });
  return response.data;
};

const recordPayment = async (statementId, amount, paymentTypeId, referenceNumber) => {
  const loggedInUser = JSON.parse(sessionStorage.getItem("loggedInUser"));
  const formData = new FormData();
  formData.append("operation", "insertPayment");
  formData.append(
    "json",
    JSON.stringify({
      statementId,
      amount: Number(amount),
      paymentTypeId,
      referenceNumber,
      userId: loggedInUser.user_id,
    })
  );
  const response = await axios({ url: `${sessionStorage.baseAPIUrl}/payment.php`, method: "POST", data: formData });
  return response.data;
};
