export const assignRoomModal = async (bookingId, refreshDisplay) => {
  const myModal = new bootstrap.Modal(document.getElementById("blank-modal"), {
    keyboard: true,
    backdrop: "static",
  });

  document.getElementById("blank-modal-title").innerText = "Assign Room to Booking";

  const availableRooms = await getAvailableRooms();

  let options = availableRooms
    .map((r) => `<option value="${r.room_id}" data-rate="${r.rate_per_night}">${r.room_number} - ${r.room_type_name} (${r.rate_per_night}/night)</option>`)
    .join("");

  document.getElementById("blank-main-div").innerHTML = `
    <div class="col-md-12">
      <label class="form-label">Available Room</label>
      <select id="assign-room-select" class="form-select">${options}</select>
    </div>
  `;

  const modalFooter = document.getElementById("blank-modal-footer");
  modalFooter.innerHTML = `
      <button type="button" class="btn btn-primary btn-sm w-100 btn-assign">ASSIGN</button>
      <button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>
    `;

  modalFooter.querySelector(".btn-assign").addEventListener("click", async () => {
    const select = document.getElementById("assign-room-select");
    const roomId = select.value;
    const rate = select.options[select.selectedIndex].dataset.rate;

    if (await assignRoom(bookingId, roomId, rate) == 1) {
      refreshDisplay();
      alert("Room has been assigned to the booking!");
      myModal.hide();
    } else {
      alert("ERROR");
    }
  });

  myModal.show();
};

export const bookingDetailsModal = async (bookingId, refreshDisplay) => {
  const myModal = bootstrap.Modal.getOrCreateInstance(document.getElementById("blank-modal"), {
    keyboard: true,
    backdrop: "static",
  });

  document.getElementById("blank-modal-title").innerText = "Booking Details";

  const rooms = await getRoomsByBooking(bookingId);
  const charges = await getChargesByBooking(bookingId);
  const serviceTypes = await getServiceTypes();

  let roomRows = rooms
    .map(
      (r) => `
      <tr>
        <td>${r.room_number}</td>
        <td>${r.room_type_name}</td>
        <td>${r.rate_charged}</td>
        <td>${r.booking_status}</td>
        <td>
          ${r.booking_status == "Reserved" ? `<button class="btn btn-success btn-sm btn-checkin" data-id="${r.booking_room_id}" data-room="${r.room_id}">Check-In</button>` : ""}
          ${r.booking_status == "Checked-In" ? `<button class="btn btn-warning btn-sm btn-checkout" data-id="${r.booking_room_id}" data-room="${r.room_id}">Check-Out</button>` : ""}
          <button class="btn btn-danger btn-sm btn-remove-room" data-id="${r.booking_room_id}" data-room="${r.room_id}">Remove</button>
        </td>
      </tr>`
    )
    .join("");

  let chargeRows = charges
    .map(
      (c) => `
      <tr>
        <td>${c.service_type}</td>
        <td>${c.unit_price}</td>
        <td>${c.number_of_guests}</td>
        <td>${c.total_amount}</td>
        <td><button class="btn btn-danger btn-sm btn-remove-charge" data-id="${c.charge_id}">Remove</button></td>
      </tr>`
    )
    .join("");

  let serviceOptions = serviceTypes
    .map((s) => `<option value="${s.service_type_id}" data-fee="${s.service_fee}" data-taxable="${s.is_taxable}">${s.service_type}</option>`)
    .join("");

  document.getElementById("blank-main-div").innerHTML = `
    <div class="col-md-12">
      <h6>Rooms</h6>
      <table class="table table-sm">
        <thead><tr><th>Room</th><th>Type</th><th>Rate</th><th>Status</th><th></th></tr></thead>
        <tbody id="booking-rooms-body">${roomRows}</tbody>
      </table>

      <h6>Charges</h6>
      <table class="table table-sm">
        <thead><tr><th>Service</th><th>Unit Price</th><th>Guests</th><th>Total</th><th></th></tr></thead>
        <tbody>${chargeRows}</tbody>
      </table>

      <div class="row mt-2">
        <div class="col-md-5"><select id="charge-service-type" class="form-select">${serviceOptions}</select></div>
        <div class="col-md-3"><input type="number" id="charge-guests" class="form-control" placeholder="Guests" value="1" /></div>
        <div class="col-md-4"><button type="button" class="btn btn-primary w-100 btn-add-charge">Add Charge</button></div>
      </div>
    </div>
  `;

  const modalFooter = document.getElementById("blank-modal-footer");
  modalFooter.innerHTML = `
      <button type="button" class="btn btn-success btn-sm w-100 btn-generate-bill">GENERATE BILL</button>
      <button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>
    `;

  document.querySelectorAll(".btn-checkin").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await checkIn(btn.dataset.id, btn.dataset.room);
      bookingDetailsModal(bookingId, refreshDisplay);
    });
  });

  document.querySelectorAll(".btn-checkout").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await checkOut(btn.dataset.id, btn.dataset.room);
      bookingDetailsModal(bookingId, refreshDisplay);
    });
  });

  document.querySelectorAll(".btn-remove-room").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (confirm("Remove this room from the booking?")) {
        await removeRoom(btn.dataset.id, btn.dataset.room);
        bookingDetailsModal(bookingId, refreshDisplay);
      }
    });
  });

  document.querySelectorAll(".btn-remove-charge").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (confirm("Remove this charge?")) {
        await removeCharge(btn.dataset.id);
        bookingDetailsModal(bookingId, refreshDisplay);
      }
    });
  });

  document.querySelector(".btn-add-charge").addEventListener("click", async () => {
    const select = document.getElementById("charge-service-type");
    const serviceTypeId = select.value;
    const unitPrice = select.options[select.selectedIndex].dataset.fee;
    const isTaxable = select.options[select.selectedIndex].dataset.taxable;
    const numberOfGuests = document.getElementById("charge-guests").value;

    if (await addCharge(bookingId, serviceTypeId, unitPrice, isTaxable, numberOfGuests) == 1) {
      bookingDetailsModal(bookingId, refreshDisplay);
    } else {
      alert("ERROR");
    }
  });

  modalFooter.querySelector(".btn-generate-bill").addEventListener("click", async () => {
    if (await generateBill(bookingId) == 1) {
      refreshDisplay();
      alert("Bill and billing statement have been generated! Check the Billing & Payments tab.");
      myModal.hide();
    } else {
      alert("ERROR - make sure at least one room is assigned to this booking.");
    }
  });

  myModal.show();
};

export const cancelBookingModal = async (bookingId, refreshDisplay) => {
  document.getElementById("blank-modal-title").innerText = "Confirm Cancellation";
  document.getElementById("blank-main-div").innerHTML = `<p>Are you sure you want to cancel this booking?</p>`;

  const modalFooter = document.getElementById("blank-modal-footer");
  modalFooter.innerHTML = `
      <div class="btn-group" role="group">
        <button type="button" class="btn btn-danger btn-sm w-100 me-2 btn-delete">Cancel Booking</button>
        <button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>
      </div>
   `;

  const myModal = new bootstrap.Modal(document.getElementById("blank-modal"), {
    keyboard: true,
    backdrop: "static",
  });

  modalFooter.querySelector(".btn-delete").addEventListener("click", async () => {
    const params = { operation: "deleteBooking", json: JSON.stringify({ bookingId: bookingId }) };
    const response = await axios.get(`${sessionStorage.baseAPIUrl}/booking.php`, { params });
    if (response.data == 1) {
      refreshDisplay();
      alert("Booking has been cancelled!");
      myModal.hide();
    } else {
      alert("ERROR");
    }
  });

  myModal.show();
};

const getAvailableRooms = async () => {
  const params = { operation: "getAvailableRooms" };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/rooms.php`, { params });
  return response.data;
};

const getRoomsByBooking = async (bookingId) => {
  const params = { operation: "getRoomsByBooking", json: JSON.stringify({ bookingId }) };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/booking_room.php`, { params });
  return response.data;
};

const getChargesByBooking = async (bookingId) => {
  const params = { operation: "getChargesByBooking", json: JSON.stringify({ bookingId }) };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/charge.php`, { params });
  return response.data;
};

const getServiceTypes = async () => {
  const params = { operation: "getServiceTypes" };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/service_type.php`, { params });
  return response.data;
};

const assignRoom = async (bookingId, roomId, rateCharged) => {
  const formData = new FormData();
  formData.append("operation", "assignRoom");
  formData.append("json", JSON.stringify({ bookingId, roomId, rateCharged }));
  const response = await axios({ url: `${sessionStorage.baseAPIUrl}/booking_room.php`, method: "POST", data: formData });
  return response.data;
};

const checkIn = async (bookingRoomId, roomId) => {
  const formData = new FormData();
  formData.append("operation", "checkIn");
  formData.append("json", JSON.stringify({ bookingRoomId, roomId }));
  const response = await axios({ url: `${sessionStorage.baseAPIUrl}/booking_room.php`, method: "POST", data: formData });
  return response.data;
};

const checkOut = async (bookingRoomId, roomId) => {
  const formData = new FormData();
  formData.append("operation", "checkOut");
  formData.append("json", JSON.stringify({ bookingRoomId, roomId }));
  const response = await axios({ url: `${sessionStorage.baseAPIUrl}/booking_room.php`, method: "POST", data: formData });
  return response.data;
};

const removeRoom = async (bookingRoomId, roomId) => {
  const formData = new FormData();
  formData.append("operation", "removeRoom");
  formData.append("json", JSON.stringify({ bookingRoomId, roomId }));
  const response = await axios({ url: `${sessionStorage.baseAPIUrl}/booking_room.php`, method: "POST", data: formData });
  return response.data;
};

const addCharge = async (bookingId, serviceTypeId, unitPrice, isTaxable, numberOfGuests) => {
  const formData = new FormData();
  formData.append("operation", "insertCharge");
  formData.append(
    "json",
    JSON.stringify({ bookingId, serviceTypeId, unitPrice: Number(unitPrice), isTaxable: Number(isTaxable), numberOfGuests: Number(numberOfGuests) })
  );
  const response = await axios({ url: `${sessionStorage.baseAPIUrl}/charge.php`, method: "POST", data: formData });
  return response.data;
};

const removeCharge = async (chargeId) => {
  const formData = new FormData();
  formData.append("operation", "deleteCharge");
  formData.append("json", JSON.stringify({ chargeId }));
  const response = await axios({ url: `${sessionStorage.baseAPIUrl}/charge.php`, method: "POST", data: formData });
  return response.data;
};

const generateBill = async (bookingId) => {
  const formData = new FormData();
  formData.append("operation", "generateBill");
  formData.append("json", JSON.stringify({ bookingId }));
  const response = await axios({ url: `${sessionStorage.baseAPIUrl}/bill.php`, method: "POST", data: formData });
  return response.data;
};
