<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class User {

    function login($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "SELECT a.*, b.role_type,
                     (SELECT GROUP_CONCAT(feature_key) FROM role_permission WHERE role_id = a.role_id) AS permissions
              FROM user a INNER JOIN role b
              ON a.role_id = b.role_id
              WHERE a.username = :username";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":username", $json['username']);
      $stmt->execute();
      $rs = $stmt->fetch(PDO::FETCH_ASSOC);

      $returnValue = 0;
      if($rs && password_verify($json['password'], $rs['password'])){
        if($rs['user_status'] == 'Active'){
          unset($rs['password']);
          $returnValue = $rs;
        }
      }

      return json_encode($returnValue);
    }

    function getAllUsers(){
      include "connection-pdo.php";

      $sql = "SELECT a.user_id, a.role_id, a.username, a.first_name, a.last_name,
                     a.email, a.user_status, a.created_at, b.role_type
              FROM user a INNER JOIN role b
              ON a.role_id = b.role_id
              ORDER BY a.last_name";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return json_encode($rs);
    }

    function getUser($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "SELECT user_id, role_id, username, first_name, last_name, email, user_status
              FROM user WHERE user_id = :userId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":userId", $json['userId']);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertUser($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $hashedPassword = password_hash($json['password'], PASSWORD_DEFAULT);

      $sql = "INSERT INTO user(role_id, username, password, first_name, last_name, email, user_status)
              VALUES(:roleId, :username, :password, :firstName, :lastName, :email, :userStatus)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roleId", $json['roleId']);
      $stmt->bindParam(":username", $json['username']);
      $stmt->bindParam(":password", $hashedPassword);
      $stmt->bindParam(":firstName", $json['firstName']);
      $stmt->bindParam(":lastName", $json['lastName']);
      $stmt->bindParam(":email", $json['email']);
      $stmt->bindParam(":userStatus", $json['userStatus']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function updateUser($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE user SET role_id = :roleId, username = :username, first_name = :firstName,
                last_name = :lastName, email = :email, user_status = :userStatus
              WHERE user_id = :userId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roleId", $json['roleId']);
      $stmt->bindParam(":username", $json['username']);
      $stmt->bindParam(":firstName", $json['firstName']);
      $stmt->bindParam(":lastName", $json['lastName']);
      $stmt->bindParam(":email", $json['email']);
      $stmt->bindParam(":userStatus", $json['userStatus']);
      $stmt->bindParam(":userId", $json['userId']);
      $stmt->execute();

      $returnValue = 1;
      return json_encode($returnValue);
    }

    function resetPassword($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $hashedPassword = password_hash($json['password'], PASSWORD_DEFAULT);

      $sql = "UPDATE user SET password = :password WHERE user_id = :userId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":password", $hashedPassword);
      $stmt->bindParam(":userId", $json['userId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Soft delete: USER already has a user_status column in the ERD, so
    // "deleting" an account means setting it to Inactive (it can no longer
    // log in - see login() above) instead of removing the row. USER rows
    // are referenced by BOOKING, HOUSEKEEPING and PAYMENT_AUDIT, so a hard
    // delete would break that history.
    function deactivateUser($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE user SET user_status = 'Inactive' WHERE user_id = :userId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":userId", $json['userId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function reactivateUser($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE user SET user_status = 'Active' WHERE user_id = :userId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":userId", $json['userId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Hard delete kept only for an account that was created by mistake and
    // has never been used anywhere - guarded, since a user already
    // referenced by a booking/housekeeping/payment_audit record is
    // protected by its foreign keys.
    function deleteUser($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "DELETE FROM user WHERE user_id = :userId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":userId", $json['userId']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      } catch (PDOException $e) {
        $returnValue = -1; // already used in bookings/housekeeping/payments - deactivate it instead
      }

      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $user = new User();
  switch($operation){
    case "login":
      echo $user->login($json);
      break;
    case "getAllUsers":
      echo $user->getAllUsers();
      break;
    case "getUser":
      echo $user->getUser($json);
      break;
    case "insertUser":
      echo $user->insertUser($json);
      break;
    case "updateUser":
      echo $user->updateUser($json);
      break;
    case "resetPassword":
      echo $user->resetPassword($json);
      break;
    case "deactivateUser":
      echo $user->deactivateUser($json);
      break;
    case "reactivateUser":
      echo $user->reactivateUser($json);
      break;
    case "deleteUser":
      echo $user->deleteUser($json);
      break;
    }

?>
