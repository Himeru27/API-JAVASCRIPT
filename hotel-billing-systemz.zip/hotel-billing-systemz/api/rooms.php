<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class Rooms {

    function getAllRooms(){
      include "connection-pdo.php";

      $sql = "SELECT a.room_id, a.room_type_id, a.floor_id, a.room_status_id, a.room_number,
                     b.room_type_name, b.rate_per_night, c.floor_name, d.room_status
              FROM rooms a
              INNER JOIN room_type b ON a.room_type_id = b.room_type_id
              INNER JOIN floor c ON a.floor_id = c.floor_id
              INNER JOIN room_status d ON a.room_status_id = d.room_status_id
              ORDER BY c.floor_number, a.room_number";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return json_encode($rs);
    }

    function getAvailableRooms(){
      include "connection-pdo.php";

      $sql = "SELECT a.room_id, a.room_number, b.room_type_name, b.rate_per_night, c.floor_name
              FROM rooms a
              INNER JOIN room_type b ON a.room_type_id = b.room_type_id
              INNER JOIN floor c ON a.floor_id = c.floor_id
              INNER JOIN room_status d ON a.room_status_id = d.room_status_id
              WHERE d.room_status = 'Available'
              ORDER BY a.room_number";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return json_encode($rs);
    }

    function insertRoom($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO rooms(room_type_id, floor_id, room_status_id, room_number)
              VALUES(:roomTypeId, :floorId, :roomStatusId, :roomNumber)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roomTypeId", $json['roomTypeId']);
      $stmt->bindParam(":floorId", $json['floorId']);
      $stmt->bindParam(":roomStatusId", $json['roomStatusId']);
      $stmt->bindParam(":roomNumber", $json['roomNumber']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function updateRoom($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE rooms SET room_type_id = :roomTypeId, floor_id = :floorId,
                room_status_id = :roomStatusId, room_number = :roomNumber
              WHERE room_id = :roomId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roomTypeId", $json['roomTypeId']);
      $stmt->bindParam(":floorId", $json['floorId']);
      $stmt->bindParam(":roomStatusId", $json['roomStatusId']);
      $stmt->bindParam(":roomNumber", $json['roomNumber']);
      $stmt->bindParam(":roomId", $json['roomId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function updateRoomStatus($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE rooms SET room_status_id = :roomStatusId WHERE room_id = :roomId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roomStatusId", $json['roomStatusId']);
      $stmt->bindParam(":roomId", $json['roomId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Soft delete: ROOMS is heavily referenced by BOOKING_ROOM and
    // HOUSEKEEPING, so instead of removing the row we mark the room
    // "Retired" using the existing ROOM_STATUS lookup - this keeps every
    // past booking/housekeeping record valid while taking the room out of
    // circulation for new bookings.
    function retireRoom($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $retiredStatusId = $this->getRoomStatusIdByName($conn, 'Retired');

      $sql = "UPDATE rooms SET room_status_id = :roomStatusId WHERE room_id = :roomId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roomStatusId", $retiredStatusId);
      $stmt->bindParam(":roomId", $json['roomId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function reactivateRoom($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $availableStatusId = $this->getRoomStatusIdByName($conn, 'Available');

      $sql = "UPDATE rooms SET room_status_id = :roomStatusId WHERE room_id = :roomId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roomStatusId", $availableStatusId);
      $stmt->bindParam(":roomId", $json['roomId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Hard delete kept only for a room that was created by mistake and has
    // never been used anywhere - guarded, since a room already referenced
    // by a booking or housekeeping record is protected by its foreign keys.
    function deleteRoom($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "DELETE FROM rooms WHERE room_id = :roomId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":roomId", $json['roomId']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      } catch (PDOException $e) {
        $returnValue = -1; // already used in bookings/housekeeping - retire it instead
      }

      return json_encode($returnValue);
    }

    function getRoomStatusIdByName($conn, $statusName){
      $sql = "SELECT room_status_id FROM room_status WHERE room_status = :statusName";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":statusName", $statusName);
      $stmt->execute();
      $rs = $stmt->fetch(PDO::FETCH_ASSOC);
      if ($rs) return $rs['room_status_id'];

      // status row is missing from this database - create it instead of
      // failing, so retire/reactivate never breaks due to missing seed data
      $insertSql = "INSERT INTO room_status(room_status) VALUES(:statusName)";
      $insertStmt = $conn->prepare($insertSql);
      $insertStmt->bindParam(":statusName", $statusName);
      $insertStmt->execute();
      return $conn->lastInsertId();
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $rooms = new Rooms();
  switch($operation){
    case "getAllRooms":
      echo $rooms->getAllRooms();
      break;
    case "getAvailableRooms":
      echo $rooms->getAvailableRooms();
      break;
    case "insertRoom":
      echo $rooms->insertRoom($json);
      break;
    case "updateRoom":
      echo $rooms->updateRoom($json);
      break;
    case "updateRoomStatus":
      echo $rooms->updateRoomStatus($json);
      break;
    case "retireRoom":
      echo $rooms->retireRoom($json);
      break;
    case "reactivateRoom":
      echo $rooms->reactivateRoom($json);
      break;
    case "deleteRoom":
      echo $rooms->deleteRoom($json);
      break;
    }

?>
