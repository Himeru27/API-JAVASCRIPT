<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class Charge {

    function getChargesByBooking($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "SELECT a.charge_id, a.booking_id, a.bill_id, a.service_type_id, a.price_date,
                     a.unit_price, a.tax_amount, a.number_of_guests, a.total_amount,
                     b.service_type
              FROM charge a
              INNER JOIN service_type b ON a.service_type_id = b.service_type_id
              WHERE a.booking_id = :bookingId
              ORDER BY a.price_date DESC";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":bookingId", $json['bookingId']);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertCharge($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $unitPrice = $json['unitPrice'];
      $numberOfGuests = $json['numberOfGuests'];
      $taxRate = 0.12; // 12% VAT

      $lineTotal = $unitPrice * $numberOfGuests;
      $taxAmount = $json['isTaxable'] ? round($lineTotal * $taxRate, 2) : 0;
      $totalAmount = $lineTotal + $taxAmount;

      $sql = "INSERT INTO charge(booking_id, service_type_id, unit_price, tax_amount, number_of_guests, total_amount)
              VALUES(:bookingId, :serviceTypeId, :unitPrice, :taxAmount, :numberOfGuests, :totalAmount)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":bookingId", $json['bookingId']);
      $stmt->bindParam(":serviceTypeId", $json['serviceTypeId']);
      $stmt->bindParam(":unitPrice", $unitPrice);
      $stmt->bindParam(":taxAmount", $taxAmount);
      $stmt->bindParam(":numberOfGuests", $numberOfGuests);
      $stmt->bindParam(":totalAmount", $totalAmount);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function deleteCharge($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "DELETE FROM charge WHERE charge_id = :chargeId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":chargeId", $json['chargeId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $charge = new Charge();
  switch($operation){
    case "getChargesByBooking":
      echo $charge->getChargesByBooking($json);
      break;
    case "insertCharge":
      echo $charge->insertCharge($json);
      break;
    case "deleteCharge":
      echo $charge->deleteCharge($json);
      break;
    }

?>
