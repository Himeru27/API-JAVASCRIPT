<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class RoomStatus {

    function getRoomStatuses(){
      include "connection-pdo.php";

      $sql = "SELECT room_status_id, room_status
              FROM room_status
              ORDER BY room_status_id";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertRoomStatus($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO room_status(room_status) VALUES(:roomStatus)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roomStatus", $json['roomStatus']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function updateRoomStatus($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE room_status SET room_status = :roomStatus WHERE room_status_id = :roomStatusId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roomStatus", $json['roomStatus']);
      $stmt->bindParam(":roomStatusId", $json['roomStatusId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Hard delete, guarded: ROOM_STATUS has no status-of-its-own column, so a
    // status still in use by a room or housekeeping record is protected by
    // the room_status_id foreign key.
    function deleteRoomStatus($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "DELETE FROM room_status WHERE room_status_id = :roomStatusId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":roomStatusId", $json['roomStatusId']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      } catch (PDOException $e) {
        $returnValue = -1; // still in use by existing rooms/housekeeping records
      }

      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $roomStatus = new RoomStatus();
  switch($operation){
    case "getRoomStatuses":
      echo $roomStatus->getRoomStatuses();
      break;
    case "insertRoomStatus":
      echo $roomStatus->insertRoomStatus($json);
      break;
    case "updateRoomStatus":
      echo $roomStatus->updateRoomStatus($json);
      break;
    case "deleteRoomStatus":
      echo $roomStatus->deleteRoomStatus($json);
      break;
    }

?>
