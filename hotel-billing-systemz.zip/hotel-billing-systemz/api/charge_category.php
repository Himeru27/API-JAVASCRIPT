<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class ChargeCategory {

    function getChargeCategories(){
      include "connection-pdo.php";

      $sql = "SELECT charge_category_id, charge_category, charge_type, default_price, is_taxable
              FROM charge_category
              ORDER BY charge_category";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertChargeCategory($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO charge_category(charge_category, charge_type, default_price, is_taxable)
              VALUES(:chargeCategory, :chargeType, :defaultPrice, :isTaxable)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":chargeCategory", $json['chargeCategory']);
      $stmt->bindParam(":chargeType", $json['chargeType']);
      $stmt->bindParam(":defaultPrice", $json['defaultPrice']);
      $stmt->bindParam(":isTaxable", $json['isTaxable']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function updateChargeCategory($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE charge_category SET charge_category = :chargeCategory, charge_type = :chargeType,
                default_price = :defaultPrice, is_taxable = :isTaxable
              WHERE charge_category_id = :chargeCategoryId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":chargeCategory", $json['chargeCategory']);
      $stmt->bindParam(":chargeType", $json['chargeType']);
      $stmt->bindParam(":defaultPrice", $json['defaultPrice']);
      $stmt->bindParam(":isTaxable", $json['isTaxable']);
      $stmt->bindParam(":chargeCategoryId", $json['chargeCategoryId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Hard delete, guarded: CHARGE_CATEGORY has no status column in the ERD,
    // so a category still used by a service type is protected by the FK.
    function deleteChargeCategory($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "DELETE FROM charge_category WHERE charge_category_id = :chargeCategoryId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":chargeCategoryId", $json['chargeCategoryId']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      } catch (PDOException $e) {
        $returnValue = -1; // still referenced by existing service types
      }

      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $chargeCategory = new ChargeCategory();
  switch($operation){
    case "getChargeCategories":
      echo $chargeCategory->getChargeCategories();
      break;
    case "insertChargeCategory":
      echo $chargeCategory->insertChargeCategory($json);
      break;
    case "updateChargeCategory":
      echo $chargeCategory->updateChargeCategory($json);
      break;
    case "deleteChargeCategory":
      echo $chargeCategory->deleteChargeCategory($json);
      break;
    }

?>
