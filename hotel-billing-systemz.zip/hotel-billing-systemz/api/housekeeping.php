<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class Housekeeping {

    function getAllHousekeeping(){
      include "connection-pdo.php";

      $sql = "SELECT a.housekeep_id, a.user_id, a.room_status_id, a.room_id,
                     a.housekeeping_status, a.is_active,
                     b.username, c.room_number, d.room_status
              FROM housekeeping a
              INNER JOIN user b ON a.user_id = b.user_id
              INNER JOIN rooms c ON a.room_id = c.room_id
              INNER JOIN room_status d ON a.room_status_id = d.room_status_id
              ORDER BY a.housekeep_id DESC";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return json_encode($rs);
    }

    function insertHousekeeping($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO housekeeping(user_id, room_status_id, room_id, housekeeping_status, is_active)
              VALUES(:userId, :roomStatusId, :roomId, :housekeepingStatus, :isActive)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":userId", $json['userId']);
      $stmt->bindParam(":roomStatusId", $json['roomStatusId']);
      $stmt->bindParam(":roomId", $json['roomId']);
      $stmt->bindParam(":housekeepingStatus", $json['housekeepingStatus']);
      $stmt->bindParam(":isActive", $json['isActive']);
      $stmt->execute();

      //also reflect the new status on the room itself
      $sql2 = "UPDATE rooms SET room_status_id = :roomStatusId WHERE room_id = :roomId";
      $stmt2 = $conn->prepare($sql2);
      $stmt2->bindParam(":roomStatusId", $json['roomStatusId']);
      $stmt2->bindParam(":roomId", $json['roomId']);
      $stmt2->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $housekeeping = new Housekeeping();
  switch($operation){
    case "getAllHousekeeping":
      echo $housekeeping->getAllHousekeeping();
      break;
    case "insertHousekeeping":
      echo $housekeeping->insertHousekeeping($json);
      break;
    }

?>
