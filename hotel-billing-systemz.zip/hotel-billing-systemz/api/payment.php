<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class Payment {

    function getPaymentsByStatement($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "SELECT a.payment_id, a.statement_id, a.payment_type_id, a.payment_status_id,
                     a.payment_date, a.amount, a.reference_number,
                     b.payment_type_name, c.status_name
              FROM payment a
              INNER JOIN payment_type b ON a.payment_type_id = b.payment_type_id
              INNER JOIN payment_status c ON a.payment_status_id = c.payment_status_id
              WHERE a.statement_id = :statementId
              ORDER BY a.payment_date DESC";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":statementId", $json['statementId']);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertPayment($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      //how much is owed and how much has already been paid
      $sql = "SELECT amount_due FROM billing_statement WHERE statement_id = :statementId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":statementId", $json['statementId']);
      $stmt->execute();
      $amountDue = $stmt->fetch(PDO::FETCH_ASSOC)['amount_due'];

      $sql2 = "SELECT COALESCE(SUM(amount), 0) AS total_paid FROM payment WHERE statement_id = :statementId";
      $stmt2 = $conn->prepare($sql2);
      $stmt2->bindParam(":statementId", $json['statementId']);
      $stmt2->execute();
      $totalPaidBefore = $stmt2->fetch(PDO::FETCH_ASSOC)['total_paid'];

      $totalPaidAfter = $totalPaidBefore + $json['amount'];

      $statusName = 'Pending';
      if($totalPaidAfter >= $amountDue){
        $statusName = 'Paid';
      }else if($totalPaidAfter > 0){
        $statusName = 'Partially Paid';
      }

      $sql3 = "SELECT payment_status_id FROM payment_status WHERE status_name = :statusName";
      $stmt3 = $conn->prepare($sql3);
      $stmt3->bindParam(":statusName", $statusName);
      $stmt3->execute();
      $paymentStatusId = $stmt3->fetch(PDO::FETCH_ASSOC)['payment_status_id'];

      $sql4 = "INSERT INTO payment(statement_id, payment_type_id, payment_status_id, amount, reference_number)
               VALUES(:statementId, :paymentTypeId, :paymentStatusId, :amount, :referenceNumber)";
      $stmt4 = $conn->prepare($sql4);
      $stmt4->bindParam(":statementId", $json['statementId']);
      $stmt4->bindParam(":paymentTypeId", $json['paymentTypeId']);
      $stmt4->bindParam(":paymentStatusId", $paymentStatusId);
      $stmt4->bindParam(":amount", $json['amount']);
      $stmt4->bindParam(":referenceNumber", $json['referenceNumber']);
      $stmt4->execute();

      $paymentId = $conn->lastInsertId();

      //log the payment audit trail
      $action = "Payment of " . number_format($json['amount'], 2) . " recorded (" . $statusName . ")";
      $sql5 = "INSERT INTO payment_audit(payment_id, user_id, action) VALUES(:paymentId, :userId, :action)";
      $stmt5 = $conn->prepare($sql5);
      $stmt5->bindParam(":paymentId", $paymentId);
      $stmt5->bindParam(":userId", $json['userId']);
      $stmt5->bindParam(":action", $action);
      $stmt5->execute();

      $returnValue = $paymentId ? 1 : 0;
      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $payment = new Payment();
  switch($operation){
    case "getPaymentsByStatement":
      echo $payment->getPaymentsByStatement($json);
      break;
    case "insertPayment":
      echo $payment->insertPayment($json);
      break;
    }

?>
