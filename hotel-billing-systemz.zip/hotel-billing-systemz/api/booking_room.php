<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class BookingRoom {

    function getRoomsByBooking($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "SELECT a.booking_room_id, a.booking_id, a.room_id, a.rate_charged,
                     a.booking_status, a.date, b.room_number, c.room_type_name
              FROM booking_room a
              INNER JOIN rooms b ON a.room_id = b.room_id
              INNER JOIN room_type c ON b.room_type_id = c.room_type_id
              WHERE a.booking_id = :bookingId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":bookingId", $json['bookingId']);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function assignRoom($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO booking_room(booking_id, room_id, rate_charged, booking_status)
              VALUES(:bookingId, :roomId, :rateCharged, 'Reserved')";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":bookingId", $json['bookingId']);
      $stmt->bindParam(":roomId", $json['roomId']);
      $stmt->bindParam(":rateCharged", $json['rateCharged']);
      $stmt->execute();

      //mark the room as reserved
      $occupiedStatusId = $this->getRoomStatusIdByName($conn, 'Reserved');
      $sql2 = "UPDATE rooms SET room_status_id = :roomStatusId WHERE room_id = :roomId";
      $stmt2 = $conn->prepare($sql2);
      $stmt2->bindParam(":roomStatusId", $occupiedStatusId);
      $stmt2->bindParam(":roomId", $json['roomId']);
      $stmt2->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function checkIn($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE booking_room SET booking_status = 'Checked-In' WHERE booking_room_id = :bookingRoomId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":bookingRoomId", $json['bookingRoomId']);
      $stmt->execute();

      $occupiedStatusId = $this->getRoomStatusIdByName($conn, 'Occupied');
      $sql2 = "UPDATE rooms SET room_status_id = :roomStatusId WHERE room_id = :roomId";
      $stmt2 = $conn->prepare($sql2);
      $stmt2->bindParam(":roomStatusId", $occupiedStatusId);
      $stmt2->bindParam(":roomId", $json['roomId']);
      $stmt2->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function checkOut($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE booking_room SET booking_status = 'Checked-Out' WHERE booking_room_id = :bookingRoomId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":bookingRoomId", $json['bookingRoomId']);
      $stmt->execute();

      $availableStatusId = $this->getRoomStatusIdByName($conn, 'Available');
      $sql2 = "UPDATE rooms SET room_status_id = :roomStatusId WHERE room_id = :roomId";
      $stmt2 = $conn->prepare($sql2);
      $stmt2->bindParam(":roomStatusId", $availableStatusId);
      $stmt2->bindParam(":roomId", $json['roomId']);
      $stmt2->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function removeRoom($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "DELETE FROM booking_room WHERE booking_room_id = :bookingRoomId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":bookingRoomId", $json['bookingRoomId']);
      $stmt->execute();

      $availableStatusId = $this->getRoomStatusIdByName($conn, 'Available');
      $sql2 = "UPDATE rooms SET room_status_id = :roomStatusId WHERE room_id = :roomId";
      $stmt2 = $conn->prepare($sql2);
      $stmt2->bindParam(":roomStatusId", $availableStatusId);
      $stmt2->bindParam(":roomId", $json['roomId']);
      $stmt2->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function getRoomStatusIdByName($conn, $statusName){
      $sql = "SELECT room_status_id FROM room_status WHERE room_status = :statusName";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":statusName", $statusName);
      $stmt->execute();
      $rs = $stmt->fetch(PDO::FETCH_ASSOC);
      return $rs ? $rs['room_status_id'] : null;
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $bookingRoom = new BookingRoom();
  switch($operation){
    case "getRoomsByBooking":
      echo $bookingRoom->getRoomsByBooking($json);
      break;
    case "assignRoom":
      echo $bookingRoom->assignRoom($json);
      break;
    case "checkIn":
      echo $bookingRoom->checkIn($json);
      break;
    case "checkOut":
      echo $bookingRoom->checkOut($json);
      break;
    case "removeRoom":
      echo $bookingRoom->removeRoom($json);
      break;
    }

?>
