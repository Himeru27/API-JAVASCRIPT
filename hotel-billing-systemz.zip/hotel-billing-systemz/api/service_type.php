<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class ServiceType {

    function getServiceTypes(){
      include "connection-pdo.php";

      $sql = "SELECT a.service_type_id, a.charge_category_id, a.service_type, a.service_fee,
                     b.charge_category, b.is_taxable
              FROM service_type a
              INNER JOIN charge_category b ON a.charge_category_id = b.charge_category_id
              ORDER BY a.service_type";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertServiceType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO service_type(charge_category_id, service_type, service_fee)
              VALUES(:chargeCategoryId, :serviceType, :serviceFee)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":chargeCategoryId", $json['chargeCategoryId']);
      $stmt->bindParam(":serviceType", $json['serviceType']);
      $stmt->bindParam(":serviceFee", $json['serviceFee']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function updateServiceType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE service_type SET charge_category_id = :chargeCategoryId, service_type = :serviceType,
                service_fee = :serviceFee
              WHERE service_type_id = :serviceTypeId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":chargeCategoryId", $json['chargeCategoryId']);
      $stmt->bindParam(":serviceType", $json['serviceType']);
      $stmt->bindParam(":serviceFee", $json['serviceFee']);
      $stmt->bindParam(":serviceTypeId", $json['serviceTypeId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Hard delete, guarded: SERVICE_TYPE has no status column in the ERD, so
    // a service type already used on a charge is protected by the FK.
    function deleteServiceType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "DELETE FROM service_type WHERE service_type_id = :serviceTypeId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":serviceTypeId", $json['serviceTypeId']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      } catch (PDOException $e) {
        $returnValue = -1; // still referenced by existing charges
      }

      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $serviceType = new ServiceType();
  switch($operation){
    case "getServiceTypes":
      echo $serviceType->getServiceTypes();
      break;
    case "insertServiceType":
      echo $serviceType->insertServiceType($json);
      break;
    case "updateServiceType":
      echo $serviceType->updateServiceType($json);
      break;
    case "deleteServiceType":
      echo $serviceType->deleteServiceType($json);
      break;
    }

?>
