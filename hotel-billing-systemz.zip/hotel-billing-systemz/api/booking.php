<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class Booking {

    function getAllBookings(){
      include "connection-pdo.php";

      $sql = "SELECT a.booking_id, a.guest_id, a.user_id, a.booking_date, a.check_in_date,
                     a.check_out_date, a.quantity,
                     b.first_name, b.last_name, b.guest_type_id,
                     c.username
              FROM booking a
              INNER JOIN guest b ON a.guest_id = b.guest_id
              INNER JOIN user c ON a.user_id = c.user_id
              ORDER BY a.booking_id DESC";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return json_encode($rs);
    }

    function getBooking($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "SELECT a.booking_id, a.guest_id, a.user_id, a.booking_date, a.check_in_date,
                     a.check_out_date, a.quantity,
                     b.first_name, b.last_name, b.guest_type_id
              FROM booking a
              INNER JOIN guest b ON a.guest_id = b.guest_id
              WHERE a.booking_id = :bookingId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":bookingId", $json['bookingId']);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertBooking($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO booking(guest_id, user_id, check_in_date, check_out_date, quantity)
              VALUES(:guestId, :userId, :checkInDate, :checkOutDate, :quantity)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":guestId", $json['guestId']);
      $stmt->bindParam(":userId", $json['userId']);
      $stmt->bindParam(":checkInDate", $json['checkInDate']);
      $stmt->bindParam(":checkOutDate", $json['checkOutDate']);
      $stmt->bindParam(":quantity", $json['quantity']);
      $stmt->execute();

      $returnValue = 0;
      if($stmt->rowCount() > 0){
        $returnValue = $conn->lastInsertId();
      }

      return json_encode($returnValue);
    }

    function deleteBooking($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "DELETE FROM booking WHERE booking_id = :bookingId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":bookingId", $json['bookingId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $booking = new Booking();
  switch($operation){
    case "getAllBookings":
      echo $booking->getAllBookings();
      break;
    case "getBooking":
      echo $booking->getBooking($json);
      break;
    case "insertBooking":
      echo $booking->insertBooking($json);
      break;
    case "deleteBooking":
      echo $booking->deleteBooking($json);
      break;
    }

?>
