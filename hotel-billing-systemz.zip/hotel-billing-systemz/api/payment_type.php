<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class PaymentType {

    function getPaymentTypes(){
      include "connection-pdo.php";

      $sql = "SELECT payment_type_id, payment_type_name
              FROM payment_type
              ORDER BY payment_type_name";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertPaymentType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO payment_type(payment_type_name) VALUES(:paymentTypeName)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":paymentTypeName", $json['paymentTypeName']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function updatePaymentType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE payment_type SET payment_type_name = :paymentTypeName WHERE payment_type_id = :paymentTypeId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":paymentTypeName", $json['paymentTypeName']);
      $stmt->bindParam(":paymentTypeId", $json['paymentTypeId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Hard delete, guarded: PAYMENT_TYPE has no status column in the ERD, so
    // a type still used by a payment is protected by the payment_type_id FK.
    function deletePaymentType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "DELETE FROM payment_type WHERE payment_type_id = :paymentTypeId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":paymentTypeId", $json['paymentTypeId']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      } catch (PDOException $e) {
        $returnValue = -1; // still referenced by existing payments
      }

      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $paymentType = new PaymentType();
  switch($operation){
    case "getPaymentTypes":
      echo $paymentType->getPaymentTypes();
      break;
    case "insertPaymentType":
      echo $paymentType->insertPaymentType($json);
      break;
    case "updatePaymentType":
      echo $paymentType->updatePaymentType($json);
      break;
    case "deletePaymentType":
      echo $paymentType->deletePaymentType($json);
      break;
    }

?>
