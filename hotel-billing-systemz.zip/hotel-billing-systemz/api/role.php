<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class Role {

    function getRoles(){
      include "connection-pdo.php";

      $sql = "SELECT role_id, role_type, role_description
              FROM role
              ORDER BY role_type";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertRole($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "INSERT INTO role(role_type, role_description) VALUES(:roleType, :roleDescription)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":roleType", $json['roleType']);
        $stmt->bindParam(":roleDescription", $json['roleDescription']);
        $stmt->execute();
        $returnValue = ["success" => 1];
      } catch (PDOException $e) {
        $returnValue = ["success" => 0, "error" => $e->getMessage()];
      } catch (Throwable $e) {
        $returnValue = ["success" => 0, "error" => $e->getMessage()];
      }

      return json_encode($returnValue);
    }

    function updateRole($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "UPDATE role SET role_type = :roleType, role_description = :roleDescription
                WHERE role_id = :roleId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":roleType", $json['roleType']);
        $stmt->bindParam(":roleDescription", $json['roleDescription']);
        $stmt->bindParam(":roleId", $json['roleId']);
        $stmt->execute();
        // Success means the query ran without error - NOT that a column's
        // value actually changed. MySQL's rowCount() on an UPDATE only
        // counts rows it changed, so editing a role without touching its
        // name/description (e.g. only toggling Allowed Tabs) would report
        // rowCount() == 0 and be wrongly treated as a failure.
        $returnValue = ["success" => 1];
      } catch (PDOException $e) {
        $returnValue = ["success" => 0, "error" => $e->getMessage()];
      } catch (Throwable $e) {
        $returnValue = ["success" => 0, "error" => $e->getMessage()];
      }

      return json_encode($returnValue);
    }

    // Hard delete, guarded: ROLE has no status column in the ERD, so a role
    // still assigned to a user is protected by the role_id foreign key.
    function deleteRole($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "DELETE FROM role WHERE role_id = :roleId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":roleId", $json['roleId']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      } catch (PDOException $e) {
        $returnValue = -1; // still assigned to existing users
      }

      return json_encode($returnValue);
    }

    function getRolePermissions(){
      include "connection-pdo.php";

      try {
        $this->ensureRolePermissionTable($conn);

        $sql = "SELECT role_id, feature_key FROM role_permission";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($rs);
      } catch (PDOException $e) {
        echo json_encode([]); // never let a missing/broken table crash the caller
      }
    }

    // Replaces the full set of allowed feature tabs for a role.
    function setRolePermissions($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      // Guard against a missing/invalid roleId instead of letting a bad
      // bind silently produce an empty/unexpected response.
      if (!isset($json['roleId']) || $json['roleId'] === '' || $json['roleId'] === null){
        return json_encode(["success" => 0, "error" => "Missing roleId"]);
      }
      $roleId = (int)$json['roleId'];
      $permissions = isset($json['permissions']) ? $json['permissions'] : [];

      try {
        $this->ensureRolePermissionTable($conn);

        $sql = "DELETE FROM role_permission WHERE role_id = :roleId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":roleId", $roleId, PDO::PARAM_INT);
        $stmt->execute();

        $sql2 = "INSERT INTO role_permission(role_id, feature_key) VALUES(:roleId, :featureKey)";
        $stmt2 = $conn->prepare($sql2);
        foreach ($permissions as $featureKey){
          $stmt2->bindParam(":roleId", $roleId, PDO::PARAM_INT);
          $stmt2->bindParam(":featureKey", $featureKey, PDO::PARAM_STR);
          $stmt2->execute();
        }

        $returnValue = ["success" => 1];
      } catch (PDOException $e) {
        $returnValue = ["success" => 0, "error" => $e->getMessage()];
      } catch (Throwable $e) {
        // Catches any non-PDO error (e.g. a TypeError) so the response is
        // always the expected {success, error} shape, never a bare value.
        $returnValue = ["success" => 0, "error" => $e->getMessage()];
      }

      return json_encode($returnValue);
    }

    // Creates ROLE_PERMISSION on first use if it doesn't already exist yet,
    // so this feature works even on a database that hasn't had this table's
    // CREATE statement (re-)applied.
    function ensureRolePermissionTable($conn){
      $conn->exec("CREATE TABLE IF NOT EXISTS role_permission (
        role_permission_id INT AUTO_INCREMENT PRIMARY KEY,
        role_id INT NOT NULL,
        feature_key VARCHAR(50) NOT NULL,
        FOREIGN KEY (role_id) REFERENCES role(role_id) ON DELETE CASCADE,
        UNIQUE KEY uq_role_feature (role_id, feature_key)
      )");
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $role = new Role();
  switch($operation){
    case "getRoles":
      echo $role->getRoles();
      break;
    case "insertRole":
      echo $role->insertRole($json);
      break;
    case "updateRole":
      echo $role->updateRole($json);
      break;
    case "deleteRole":
      echo $role->deleteRole($json);
      break;
    case "getRolePermissions":
      echo $role->getRolePermissions();
      break;
    case "setRolePermissions":
      echo $role->setRolePermissions($json);
      break;
    }

?>
