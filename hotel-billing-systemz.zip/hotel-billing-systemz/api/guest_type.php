<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class GuestType {

    function getGuestTypes(){
      include "connection-pdo.php";

      $sql = "SELECT guest_type_id, guest_type, discount_percentage, privilege
              FROM guest_type
              ORDER BY guest_type";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertGuestType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO guest_type(guest_type, discount_percentage, privilege)
              VALUES(:guestType, :discountPercentage, :privilege)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":guestType", $json['guestType']);
      $stmt->bindParam(":discountPercentage", $json['discountPercentage']);
      $stmt->bindParam(":privilege", $json['privilege']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function updateGuestType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE guest_type SET guest_type = :guestType, discount_percentage = :discountPercentage,
                privilege = :privilege
              WHERE guest_type_id = :guestTypeId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":guestType", $json['guestType']);
      $stmt->bindParam(":discountPercentage", $json['discountPercentage']);
      $stmt->bindParam(":privilege", $json['privilege']);
      $stmt->bindParam(":guestTypeId", $json['guestTypeId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Hard delete, guarded: GUEST_TYPE has no status column in the ERD, so a
    // record that is still referenced by a guest is protected by the
    // guest_type_id foreign key. We catch that and tell the client instead
    // of letting a raw SQL error through.
    function deleteGuestType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "DELETE FROM guest_type WHERE guest_type_id = :guestTypeId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":guestTypeId", $json['guestTypeId']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      } catch (PDOException $e) {
        $returnValue = -1; // still referenced by existing guest records
      }

      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $guestType = new GuestType();
  switch($operation){
    case "getGuestTypes":
      echo $guestType->getGuestTypes();
      break;
    case "insertGuestType":
      echo $guestType->insertGuestType($json);
      break;
    case "updateGuestType":
      echo $guestType->updateGuestType($json);
      break;
    case "deleteGuestType":
      echo $guestType->deleteGuestType($json);
      break;
    }

?>
