<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class PaymentAudit {

    function getAllAudits(){
      include "connection-pdo.php";

      $sql = "SELECT a.audit_id, a.payment_id, a.user_id, a.action, a.timestamp,
                     b.username, c.amount, c.reference_number
              FROM payment_audit a
              INNER JOIN user b ON a.user_id = b.user_id
              INNER JOIN payment c ON a.payment_id = c.payment_id
              ORDER BY a.timestamp DESC";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $paymentAudit = new PaymentAudit();
  switch($operation){
    case "getAllAudits":
      echo $paymentAudit->getAllAudits();
      break;
    }

?>
