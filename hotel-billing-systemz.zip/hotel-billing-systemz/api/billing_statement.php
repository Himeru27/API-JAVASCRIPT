<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class BillingStatement {

    function getAllStatements(){
      include "connection-pdo.php";

      $sql = "SELECT a.statement_id, a.bill_id, a.statement_date, a.amount_due,
                     b.booking_id, b.total_amount,
                     c.guest_id, d.first_name, d.last_name,
                     COALESCE((SELECT SUM(p.amount) FROM payment p WHERE p.statement_id = a.statement_id), 0) AS amount_paid
              FROM billing_statement a
              INNER JOIN bill b ON a.bill_id = b.bill_id
              INNER JOIN booking c ON b.booking_id = c.booking_id
              INNER JOIN guest d ON c.guest_id = d.guest_id
              ORDER BY a.statement_id DESC";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return json_encode($rs);
    }

    function getStatement($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "SELECT a.statement_id, a.bill_id, a.statement_date, a.amount_due,
                     b.booking_id, b.subtotal_amount, b.discount_amount, b.tax_amount, b.total_amount,
                     c.guest_id, d.first_name, d.last_name
              FROM billing_statement a
              INNER JOIN bill b ON a.bill_id = b.bill_id
              INNER JOIN booking c ON b.booking_id = c.booking_id
              INNER JOIN guest d ON c.guest_id = d.guest_id
              WHERE a.statement_id = :statementId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":statementId", $json['statementId']);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $billingStatement = new BillingStatement();
  switch($operation){
    case "getAllStatements":
      echo $billingStatement->getAllStatements();
      break;
    case "getStatement":
      echo $billingStatement->getStatement($json);
      break;
    }

?>
