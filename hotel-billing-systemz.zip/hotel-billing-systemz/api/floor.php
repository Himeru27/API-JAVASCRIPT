<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class Floor {

    function getAllFloors(){
      include "connection-pdo.php";

      $sql = "SELECT floor_id, floor_number, floor_name
              FROM floor
              ORDER BY floor_number";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return json_encode($rs);
    }

    function insertFloor($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO floor(floor_number, floor_name)
              VALUES(:floorNumber, :floorName)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":floorNumber", $json['floorNumber']);
      $stmt->bindParam(":floorName", $json['floorName']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function updateFloor($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE floor SET floor_number = :floorNumber, floor_name = :floorName
              WHERE floor_id = :floorId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":floorNumber", $json['floorNumber']);
      $stmt->bindParam(":floorName", $json['floorName']);
      $stmt->bindParam(":floorId", $json['floorId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Hard delete, guarded: FLOOR has no status column in the ERD, so a
    // floor still holding rooms is protected by the floor_id foreign key.
    function deleteFloor($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "DELETE FROM floor WHERE floor_id = :floorId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":floorId", $json['floorId']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      } catch (PDOException $e) {
        $returnValue = -1; // still has rooms assigned to it
      }

      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $floor = new Floor();
  switch($operation){
    case "getAllFloors":
      echo $floor->getAllFloors();
      break;
    case "insertFloor":
      echo $floor->insertFloor($json);
      break;
    case "updateFloor":
      echo $floor->updateFloor($json);
      break;
    case "deleteFloor":
      echo $floor->deleteFloor($json);
      break;
    }

?>
