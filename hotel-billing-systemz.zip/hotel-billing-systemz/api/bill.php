<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class Bill {

    function getBillsByBooking($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "SELECT bill_id, booking_id, bill_date, subtotal_amount, discount_amount,
                     tax_amount, total_amount
              FROM bill
              WHERE booking_id = :bookingId
              ORDER BY bill_id DESC";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":bookingId", $json['bookingId']);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function generateBill($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);
      $bookingId = $json['bookingId'];
      $taxRate = 0.12; // 12% VAT

      //get the booking, its nights, and the guest's discount
      $sql = "SELECT a.check_in_date, a.check_out_date, c.discount_percentage
              FROM booking a
              INNER JOIN guest b ON a.guest_id = b.guest_id
              INNER JOIN guest_type c ON b.guest_type_id = c.guest_type_id
              WHERE a.booking_id = :bookingId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":bookingId", $bookingId);
      $stmt->execute();
      $booking = $stmt->fetch(PDO::FETCH_ASSOC);

      $nights = (strtotime($booking['check_out_date']) - strtotime($booking['check_in_date'])) / 86400;
      $nights = $nights > 0 ? $nights : 1;

      //sum the room charges
      $sql2 = "SELECT COALESCE(SUM(rate_charged), 0) AS room_total
               FROM booking_room WHERE booking_id = :bookingId";
      $stmt2 = $conn->prepare($sql2);
      $stmt2->bindParam(":bookingId", $bookingId);
      $stmt2->execute();
      $roomTotal = $stmt2->fetch(PDO::FETCH_ASSOC)['room_total'] * $nights;


      $sql3 = "SELECT COALESCE(SUM(total_amount), 0) AS charge_total
               FROM charge WHERE booking_id = :bookingId AND bill_id IS NULL";
      $stmt3 = $conn->prepare($sql3);
      $stmt3->bindParam(":bookingId", $bookingId);
      $stmt3->execute();
      $chargeTotal = $stmt3->fetch(PDO::FETCH_ASSOC)['charge_total'];

      $subtotal = $roomTotal + $chargeTotal;
      $discountAmount = round($roomTotal * ($booking['discount_percentage'] / 100), 2);
      $taxableAmount = $roomTotal - $discountAmount;
      $taxAmount = round($taxableAmount * $taxRate, 2);
      $totalAmount = round($taxableAmount + $taxAmount + $chargeTotal, 2);

      $sql4 = "INSERT INTO bill(booking_id, subtotal_amount, discount_amount, tax_amount, total_amount)
               VALUES(:bookingId, :subtotal, :discount, :tax, :total)";
      $stmt4 = $conn->prepare($sql4);
      $stmt4->bindParam(":bookingId", $bookingId);
      $stmt4->bindParam(":subtotal", $subtotal);
      $stmt4->bindParam(":discount", $discountAmount);
      $stmt4->bindParam(":tax", $taxAmount);
      $stmt4->bindParam(":total", $totalAmount);
      $stmt4->execute();

      $billId = $conn->lastInsertId();


      $sql5 = "UPDATE charge SET bill_id = :billId WHERE booking_id = :bookingId AND bill_id IS NULL";
      $stmt5 = $conn->prepare($sql5);
      $stmt5->bindParam(":billId", $billId);
      $stmt5->bindParam(":bookingId", $bookingId);
      $stmt5->execute();


      $sql6 = "INSERT INTO billing_statement(bill_id, amount_due) VALUES(:billId, :amountDue)";
      $stmt6 = $conn->prepare($sql6);
      $stmt6->bindParam(":billId", $billId);
      $stmt6->bindParam(":amountDue", $totalAmount);
      $stmt6->execute();

      $returnValue = $billId ? 1 : 0;
      return json_encode($returnValue);
    }

  }


  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $bill = new Bill();
  switch($operation){
    case "getBillsByBooking":
      echo $bill->getBillsByBooking($json);
      break;
    case "generateBill":
      echo $bill->generateBill($json);
      break;
    }

?>
