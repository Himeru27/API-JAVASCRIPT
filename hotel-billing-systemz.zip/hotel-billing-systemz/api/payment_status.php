<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class PaymentStatus {

    function getPaymentStatuses(){
      include "connection-pdo.php";

      $sql = "SELECT payment_status_id, status_name
              FROM payment_status
              ORDER BY payment_status_id";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertPaymentStatus($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO payment_status(status_name) VALUES(:statusName)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":statusName", $json['statusName']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function updatePaymentStatus($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE payment_status SET status_name = :statusName WHERE payment_status_id = :paymentStatusId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":statusName", $json['statusName']);
      $stmt->bindParam(":paymentStatusId", $json['paymentStatusId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Hard delete, guarded: PAYMENT_STATUS has no status-of-its-own column,
    // so a status still used by a payment is protected by the FK.
    function deletePaymentStatus($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "DELETE FROM payment_status WHERE payment_status_id = :paymentStatusId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":paymentStatusId", $json['paymentStatusId']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      } catch (PDOException $e) {
        $returnValue = -1; // still referenced by existing payments
      }

      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $paymentStatus = new PaymentStatus();
  switch($operation){
    case "getPaymentStatuses":
      echo $paymentStatus->getPaymentStatuses();
      break;
    case "insertPaymentStatus":
      echo $paymentStatus->insertPaymentStatus($json);
      break;
    case "updatePaymentStatus":
      echo $paymentStatus->updatePaymentStatus($json);
      break;
    case "deletePaymentStatus":
      echo $paymentStatus->deletePaymentStatus($json);
      break;
    }

?>
