<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class Guest {

    function getAllGuests(){
      include "connection-pdo.php";

      $sql = "SELECT a.*, b.guest_type, b.discount_percentage
              FROM guest a INNER JOIN guest_type b
              ON a.guest_type_id = b.guest_type_id
              ORDER BY a.last_name";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return json_encode($rs);
    }

    function getGuest($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "SELECT a.*, b.guest_type, b.discount_percentage
              FROM guest a INNER JOIN guest_type b
              ON a.guest_type_id = b.guest_type_id
              WHERE a.guest_id = :guestId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":guestId", $json['guestId']);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      echo json_encode($rs);
    }

    function insertGuest($json){
      include "connection-pdo.php";

      $json = json_decode($json, true);
      $sql = "INSERT INTO guest(guest_type_id, first_name, last_name, contact_number, address, email)
              VALUES(:guestTypeId, :firstName, :lastName, :contactNumber, :address, :email)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":guestTypeId", $json['guestTypeId']);
      $stmt->bindParam(":firstName", $json['firstName']);
      $stmt->bindParam(":lastName", $json['lastName']);
      $stmt->bindParam(":contactNumber", $json['contactNumber']);
      $stmt->bindParam(":address", $json['address']);
      $stmt->bindParam(":email", $json['email']);
      $stmt->execute();

      $returnValue = 0;
      if($stmt->rowCount() > 0){
        $returnValue = 1;
      }

      return json_encode($returnValue);
    }

    function updateGuest($json){
      include "connection-pdo.php";

      $json = json_decode($json, true);
      $sql = "UPDATE guest SET guest_type_id = :guestTypeId, first_name = :firstName,
                last_name = :lastName, contact_number = :contactNumber,
                address = :address, email = :email
              WHERE guest_id = :guestId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":guestTypeId", $json['guestTypeId']);
      $stmt->bindParam(":firstName", $json['firstName']);
      $stmt->bindParam(":lastName", $json['lastName']);
      $stmt->bindParam(":contactNumber", $json['contactNumber']);
      $stmt->bindParam(":address", $json['address']);
      $stmt->bindParam(":email", $json['email']);
      $stmt->bindParam(":guestId", $json['guestId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Hard delete, guarded: GUEST has no status column in the ERD, so a
    // guest who already has bookings is protected by the guest_id foreign
    // key on BOOKING - this preserves booking/billing history.
    function deleteGuest($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      try {
        $sql = "DELETE FROM guest WHERE guest_id = :guestId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":guestId", $json['guestId']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      } catch (PDOException $e) {
        $returnValue = -1; // still has bookings on record
      }

      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $guest = new Guest();
  switch($operation){
    case "getAllGuests":
      echo $guest->getAllGuests();
      break;
    case "getGuest":
      echo $guest->getGuest($json);
      break;
    case "insertGuest":
      echo $guest->insertGuest($json);
      break;
    case "updateGuest":
      echo $guest->updateGuest($json);
      break;
    case "deleteGuest":
      echo $guest->deleteGuest($json);
      break;
    }

?>
