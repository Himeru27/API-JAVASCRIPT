<?php
  header('Content-Type: application/json');
  header("Access-Control-Allow-Origin: *");

  class RoomType {

    // returns every room type, plus a derived is_active flag based on
    // effective_to, for the management table
    function getAllRoomTypes(){
      include "connection-pdo.php";

      $sql = "SELECT room_type_id, room_type_name, room_type_description, capacity,
                     rate_per_night, effective_from, effective_to,
                     CASE WHEN effective_to IS NULL OR effective_to > CURDATE()
                          THEN 1 ELSE 0 END AS is_active
              FROM room_type
              ORDER BY room_type_name";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return json_encode($rs);
    }

    // only currently-effective room types - used to populate the dropdown
    // when creating/editing a room
    function getActiveRoomTypes(){
      include "connection-pdo.php";

      $sql = "SELECT room_type_id, room_type_name, room_type_description, capacity,
                     rate_per_night, effective_from, effective_to
              FROM room_type
              WHERE effective_to IS NULL OR effective_to > CURDATE()
              ORDER BY room_type_name";
      $stmt = $conn->prepare($sql);
      $stmt->execute();
      $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);

      return json_encode($rs);
    }

    function insertRoomType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "INSERT INTO room_type(room_type_name, room_type_description, capacity,
                rate_per_night, effective_from, effective_to)
              VALUES(:roomTypeName, :roomTypeDescription, :capacity,
                :ratePerNight, CURDATE(), NULL)";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roomTypeName", $json['roomTypeName']);
      $stmt->bindParam(":roomTypeDescription", $json['roomTypeDescription']);
      $stmt->bindParam(":capacity", $json['capacity']);
      $stmt->bindParam(":ratePerNight", $json['ratePerNight']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function updateRoomType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE room_type SET room_type_name = :roomTypeName,
                room_type_description = :roomTypeDescription, capacity = :capacity,
                rate_per_night = :ratePerNight
              WHERE room_type_id = :roomTypeId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roomTypeName", $json['roomTypeName']);
      $stmt->bindParam(":roomTypeDescription", $json['roomTypeDescription']);
      $stmt->bindParam(":capacity", $json['capacity']);
      $stmt->bindParam(":ratePerNight", $json['ratePerNight']);
      $stmt->bindParam(":roomTypeId", $json['roomTypeId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    // Soft delete: ROOM_TYPE already has effective_from/effective_to in the
    // ERD, so "deleting" a room type means retiring it (effective_to = today)
    // instead of removing the row - room types are referenced by ROOMS and
    // by historical bookings/rates, so hard deleting would break those.
    function retireRoomType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE room_type SET effective_to = CURDATE() WHERE room_type_id = :roomTypeId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roomTypeId", $json['roomTypeId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

    function reactivateRoomType($json){
      include "connection-pdo.php";
      $json = json_decode($json, true);

      $sql = "UPDATE room_type SET effective_to = NULL WHERE room_type_id = :roomTypeId";
      $stmt = $conn->prepare($sql);
      $stmt->bindParam(":roomTypeId", $json['roomTypeId']);
      $stmt->execute();

      $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
      return json_encode($returnValue);
    }

  }

  //submitted by the client - operation and json
  if ($_SERVER['REQUEST_METHOD'] == 'GET'){
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
  }else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
  }

  $roomType = new RoomType();
  switch($operation){
    case "getAllRoomTypes":
      echo $roomType->getAllRoomTypes();
      break;
    case "getActiveRoomTypes":
      echo $roomType->getActiveRoomTypes();
      break;
    case "insertRoomType":
      echo $roomType->insertRoomType($json);
      break;
    case "updateRoomType":
      echo $roomType->updateRoomType($json);
      break;
    case "retireRoomType":
      echo $roomType->retireRoomType($json);
      break;
    case "reactivateRoomType":
      echo $roomType->reactivateRoomType($json);
      break;
    }

?>
